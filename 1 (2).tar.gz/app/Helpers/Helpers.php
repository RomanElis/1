<?php


namespace App\Helpers;


use Illuminate\Http\Request;
use Illuminate\Support\Facades\Config;

class Helpers
{

    public static function dateRange($date_range = '')
    {
        $dateRangeEx = explode('-', $date_range);
        if(count($dateRangeEx) === 2)
        {
            $dateFrom = \DateTime::createFromFormat("d.m.Y", $dateRangeEx[0], new \DateTimeZone('Europe/Moscow'));
            if(!$dateFrom) return false;
            $dateTo = \DateTime::createFromFormat("d.m.Y", $dateRangeEx[1], new \DateTimeZone('Europe/Moscow'));
            if(!$dateTo) return false;

            $dateFromResult = $dateFrom->format('Y-m-d');
            $dateToResult = $dateTo->modify('+1 day')->format('Y-m-d');
            return [$dateFromResult, $dateToResult];
        }
        return false;
    }






    public static function getCaptchaForm($nameCap)
    {
        if (isset($nameCap)) {
            $total = rand(10, 50);
            $secret = rand(1, 10);
            $result[] = $total - $secret;
            $result[] = $total;
            $secret = substr(md5($secret), 0, 4);
            //setcookie('captcha_' . $nameCap, $secret, time()+3600);

            session(['captcha_' . $nameCap => $secret]);
            $return = $result[0] . ' + ? = ' . $result[1];
        } else {
            $return = '';
        }
        return $return;
    }

    public static function getCaptchaVerify($captcha_name, $captcha_code)
    {
        if (isset($_COOKIE['captcha_' . $captcha_name]) && $_COOKIE['captcha_' . $captcha_name] != substr(md5($captcha_code), 0, 4) || empty($captcha_code)){
            return false;
        }
        return true;
    }



    public static function getRecaptchaVerify(Request $request)
    {
        $captchaData = Config::get('settings.captcha');
        if(!(isset($captchaData['type']) && in_array($captchaData['type'], ['recaptcha_v2'])))
        {
            return false;
        }

        $recaptchaResponse = $request->get('g-recaptcha-response');
        if(!$recaptchaResponse) return false;

        $privatekey = $captchaData['recaptcha_v2_private'];
        $url = 'https://www.google.com/recaptcha/api/siteverify';
        $remoteIP = $_SERVER["REMOTE_ADDR"];
        $resp = file_get_contents($url."?secret=".$privatekey."&response=".$recaptchaResponse."&remoteip=".$remoteIP);
        $decoded = json_decode($resp);
        if ($decoded->success==false) { // Проверка не пройдена
            return false;
        }
        return true;
    }

    public static function getRecaptchaForm()
    {
        $captchaData = Config::get('settings.captcha');
        if(!(isset($captchaData['type']) && in_array($captchaData['type'], ['recaptcha_v2'])))
        {
            return '';
        }

        $lang = 'ru';
        $tpls = '<script src="https://www.google.com/recaptcha/api.js?hl=' . $lang .'"></script>
				<div class="g-form-m__field container_recaptcha">
					<div class="g-form-m__field-section">
						<div class="g-recaptcha" data-sitekey="' . $captchaData['recaptcha_v2_site'] . '"></div>
					</div>
				</div>';
        return $tpls;
    }
}
