<?php

namespace App\Exceptions;

use Exception;

class CustomTestingException extends Exception
{
    //
}
