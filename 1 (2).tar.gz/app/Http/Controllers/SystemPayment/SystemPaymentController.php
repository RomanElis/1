<?php
namespace App\Http\Controllers\SystemPayment;


use App\Models\Paid;
use App\Models\Product;
use App\Models\Purchase;
use App\Models\SystemPayment\SystemPayment;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class SystemPaymentController
{
    var $loadPayment;
    var $request;

    public function __construct(Request $request)
    {
        $this->request = $request;
    }

    /*
     * Загружаем контроллер оплаты
     */
    public function load($system, $method)
    {
        $this->loadPayment = new SystemPayment();
        $this->loadPayment->getSystems();
        $this->loadPayment->whereActivity();
        $this->loadPayment->findById($system);
        $this->loadPayment->loadCreator();

        //dd($this->loadPayment->loadCreator->checkError());

        //$payment = (new SystemPayment)->getSystems()->whereActivity()->findById($system)->loadCreator();
        if(!$this->loadPayment)
        {
            echo 'Not found system payment';
            exit;
        }

//        $nameSystem = '\App\Http\Controllers\SystemPayment\\' . $payment['controller'] . 'Callback\\' . $payment['controller'] . 'CallbackController';
//        $this->loadPayment = new $nameSystem;
//        $this->loadPayment->setConfig($payment);

        return $this->{$method}();
    }


    /*
     * Сюда осуществляется переход после того как пользователь нажимает кнопку ОПЛАТИТЬ
     */
    public function payment_paid($slug)
    {
        $paid = new Paid;
        $paid->findPay($slug);
        $paid->goPay();

        if(!isset($paid->paidData['return']))
        {
            abort(404, 'Ссылка на систему оплаты не найдена или заказ уже был оплачен.');
        }

        if($paid->paidData['return'] == 'local')
        {
            if($paid->paidData['paid'] && !$paid->paidData['paid']['status'])
            {
                abort(404, 'Не хватает средств.');
            }

            $paid->extractPaid();

            return redirect(route('payment_show', $paid->paidSlug));
        }

        if($paid->paidData['return'] == 'redirect' && !empty($paid->paidData['redirect']))
        {
            if($paid->paidData['paid'] && $paid->paidData['paid']['status'])
            {
                return false;
            }
            return redirect($paid->paidData['redirect']);
        }

        return 'SYSTEM PAYMENT - ERROR REDIRECT';
    }


    /*
     * Загрузка главной модели и модели платежной системы
     */
    private function loadPaid($slug, Request $request)
    {
        /*
         * Загружаем заказ
         */
        $paidMain = Paid::whereSlug($slug)->first();
        if(!$paidMain) {
            abort(404, 'Заказ не найден!');
        }

        /*
         * Загружаем данные заказа
         */
        $nameModel = 'App\Models\\' . $paidMain->type;
        $paidData = $nameModel::where('id', $paidMain->attach_id)->first(); // ->where('paid', 1)
        if(!$paidData) {
            abort(404, 'Данные заказа не найдены!');
        }

        $payment = $paidMain;
        $payment->data = $paidData;

        return $payment;
    }


    /*
     * Просмотр заказа
     */
    public function show($slug, Request $request)
    {
        /*
         * Загружаем модель заказа
         */
        $payment = $this->loadPaid($slug, $request);

        /*
         * Загружаем информацию о платежной системе
         */
        $paymentModel = (new SystemPayment)->getSystems()->whereActivity()->findById($payment->data->payment_method)->item();
        $payment->data->payment_name = isset($paymentModel['name']) ? $paymentModel['name'] : $payment->data->payment_method;


        $orderTitle = 'Заказ №' . $payment->id;
        if($payment->type == 'Deposit')
        {
            $orderTitle = 'Пополнение баланса, заказ №' . $payment->id;
        }

        view()->share('site_title', $orderTitle);

        //return 'Show ' . $slug . ' === ' . $page->title . $page->description;

        return view('payment',compact('payment'));
    }


    // Скачивание товар-файла
    public function goodsDownload($payment, $fileName)
    {
        $product = new Product();
        return $product->downloadFileTxt($payment->data['goods'], $fileName);
    }

    public function download($slug, Request $request)
    {
        /*
         * Загружаем модель заказа
         */
        $payment = $this->loadPaid($slug, $request);

        // Скачивание товар-файла
        if(isset($payment->data['paid']) && $payment->data['paid'] && isset($payment->data['goods']) && !empty($payment->data['goods']))
        {
            return $this->goodsDownload($payment, 'goods_' . $payment->id . '-' . $payment->slug . '-' . date('d-m-Y-h-i'));
        }

        return abort(404, 'Оплаченный заказ или файл товара не найден!');
    }


    /*
     * Контроллер функция обработки результа оплаты запрашиваемая ботом
     */
    public function result()
    {
        /*
         * Загружаем системы оплаты и проверку оплаты
         */
        //$getParams = $this->loadPayment->loadGetParams();
        $getParams = $this->loadPayment->loadCreator->checkLoadParams($this->request);


        /*
         * Загружаем главную модель оплаты
         */
        $paid = new Paid;
        $getPayment = $paid->findPay($getParams->params['id']);


        //dd($getPayment->paidData);
        /*
         * Если заказ не найден возвращаем ошибку
         */
        if(!$getPayment->paidId)
        {
            return $this->loadPayment->loadCreator->checkError();
        }


        /*
         * Проверяем сумму и сигнатуру
         */
        $sign = $this->loadPayment->loadCreator->checkSignature($getPayment->paidData);
        if(!$sign['status']) return $sign['error'];


        /*
         * Выполняем заказ
         */
        $paid->goPay();
        $paid->extractPaid(true);


        /*
         * Возвращаем статус проверки
         */
        return $sign['status'];
    }


    public function success()
    {
        /*
         * Загружаем системы оплаты и проверку оплаты
         */
        //$getParams = $this->loadPayment->loadGetParams();
        $getParams = $this->loadPayment->loadCreator->checkLoadParams();


        /*
         * Загружаем главную модель оплаты, проверяем ее статус на оплату
         */
        $paid = new Paid;
        $getPayment = $paid->findPay($getParams->params['id'], 1);


        /*
         * Если заказ не найден возвращаем ошибку
         */
        if(!$getPayment->paidId)
        {
            return $this->loadPayment->loadCreator->checkError();
        }


        /*
         * Возвращаем редирект
         */
        return redirect(route('payment_show', $getPayment->paidSlug));
    }

    public function error()
    {
        return $this->success();
    }
}
