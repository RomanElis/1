<?php

namespace App\Http\Controllers\Dashboard;

use App\Http\Controllers\Controller;
use App\Models\Dashboard\Dashboard;
use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class DashboardController extends Controller
{
    public function auth()
    {
        return 'AUTH';
    }
    public function index(Request $request, Dashboard $dashboard)
    {
        view()->share('site_title', 'Панель управления и статистика по заказам');


        $dateRage = $request->get('date_range');
        if(!empty($dateRage))
        {
            $dateRangeEx = explode('-', $dateRage);
            if(count($dateRangeEx) === 2)
            {
                $getStatsWeeks = $dashboard::getStatsRange($dateRangeEx[0], $dateRangeEx[1], $request->get('filter'));
            }
        }
        else
        {
            $getStatsWeeks = $dashboard::getStatsRange(false, false, $request->get('filter'));
        }

        view()->share('entitys', $getStatsWeeks);


        $statsSumTotal = array_sum(array_column($getStatsWeeks, 'total_cost'));
        view()->share('total_cost', $statsSumTotal);


//        DB::enableQueryLog();
//
//
//        $products = Product::sum('price');
//
//        dd(DB::getQueryLog());
//        dd($products);


        $products_total = DB::table('products')
            ->select(DB::raw('SUM(stock) as stock_total, SUM(price * stock) as price_total'))
            ->where('activity', '=', '1')
            ->first();
        view()->share('products_total', $products_total);



//        if($request->ajax()){
//            return response()->json([
//                'total_cost' => $statsSumTotal
//            ]);
//        }

        return view('_managers.dashboard');
    }

    public function showLoginForm()
    {
        if(Auth::check())
        {
            return redirect()->route('dash.index');
        }

        view()->share('site_title', 'Админ панель - авторизация');
        return view('_managers.login');
    }

    public function logout(Request $request)
    {
        Auth::logout();
        return redirect()->route('dash.login');
    }

    public function createdinfo()
    {
        view()->share('site_title', 'Информация о системе');
        return view('_managers.createdinfo');
    }
}
