<?php

namespace App\Http\Controllers\Dashboard;

use App\Helpers\Helpers;
use App\Http\Controllers\Controller;
use App\Models\Dashboard\ExportToFile;
use App\Models\Deposit;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Blade;
use Illuminate\Support\Facades\DB;

class DepositDashController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {

        if($request->post('export') == 'csv')
        {
            return (new ExportToFile())->loadModel('Deposit')->exportCsv();
        }

        $order = $request->get('order') ?? 'desc';
        $orderBy = $request->get('orderby') ?? 'id';

        $where = $request->get('where');
        $search = $request->get('search');

        $modelLoad = new Deposit;
        $model = $modelLoad->orderBy($orderBy, $order);

        if(!empty($where) && !empty(!empty($search)))
        {
            if(in_array($where, ['title']))
            {
                $model->where($where, 'LIKE', '%' . $search . '%');
            }
        }

        $model->with('user');
        $model->with('paid_data');

        if($date_range = Helpers::dateRange($request->get('date_range'))) {
            $model->whereBetween(DB::raw('DATE(created_at)'), $date_range);
        }


        if(!empty($where) && !empty(!empty($search)))
        {
            if(in_array($where, ['title', 'user_email']))
            {
                $model->where($where, 'LIKE', '%' . $search . '%');
            }
            if(in_array($where, ['id', 'user_id']))
            {
                $model->where($where, '=', $search);
            }
            if(in_array($where, ['paid_data_by_id', 'user_by_name', 'user_by_email']))
            {
                $whereEx = explode('_by_', $where);
                $model->whereHas($whereEx[0], function($query) use ($whereEx, $search) {
                    $query->where($whereEx[1], 'LIKE', '%' . $search . '%');
                });
            }
        }

        $paidStatus = $request->get('paid', '1');
        if($paidStatus != 'all' && in_array($paidStatus, [0, 1]))
        {
            $model->where('paid', '=', $paidStatus);
        }

        $count = $model->count();
        $items = $model->paginate(100);

        $items->withQueryString();

        view()->share('site_title', 'Список пополнений');

        view()->share('field_allow_sort', [
            ['value' => 'id', 'label' => 'По id заказа'],
            ['value' => 'paid_data_by_id', 'label' => 'По платежному ID'],
            ['value' => 'user_email', 'label' => 'По email заказа'],
            ['value' => 'user_id', 'label' => 'По id пользователя'],
            ['value' => 'user_by_name', 'label' => 'По имени клиента'],
            ['value' => 'user_by_email', 'label' => 'По email клиента']
        ]);


        $tabsItems = $modelLoad->getFilterLinks();
        if($tabsItems)
        {
            $filter_links = [
                [
                    'href'    => route('dash.deposits.index', ['paid' => 'all']),
                    'label'   => 'Все',
                    'count'   => $tabsItems['all'],
                    'current' => $request->get('paid') == 'all' ? true : false
                ],
                [
                    'href'    => route('dash.deposits.index', ['paid' => '1']),
                    'label'   => 'Оплаченные',
                    'count'   => isset($tabsItems['1']) ? $tabsItems['1'] : 0,
                    'current' => ($request->get('paid', '1') == '1') ? true : false
                ],
                [
                    'href'    => route('dash.deposits.index', ['paid' => '0']),
                    'label'   => 'Ожидают оплаты (временные)',
                    'count'   => isset($tabsItems['0']) ? $tabsItems['0'] : 0,
                    'current' => $request->get('paid') == '0' ? true : false
                ]
            ];
            view()->share('filter_links', $filter_links);
        }

        Blade::include('_managers.form.input', 'formElement');

        return view('_managers.crud.table', [
            'route_entity_update'      => false,
            'controller_name' => substr(get_class($this), strrpos(get_class($this), '\\') + 1),
            'items'           => $items,
            'count'           => $count,
            'param_orderby'   => $orderBy,
            'cruds'           => $modelLoad->cruds()
        ]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        view()->share('site_title', 'Пополнить баланс пользователю');
        Blade::include('_managers.form.input', 'formElement');
        return view('_managers.deposits.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request, [
            'user_id'        => 'required|exists:App\Models\User,id',
            'payment_total'  => 'required|numeric',
            'paid'           => 'required'
        ]);


        /*
         * Загружаем данные пользователя
         */
        $user = User::find($request->get('user_id'));
        if(!$user)
        {
            return back()->withErrors([__('messages.error.action')])->withInput($request->all());
        }
        $balancePlus = $user->changeBalance('plus', $request->get('payment_total'));
        if(!$balancePlus['status'])
        {
            return back()->withErrors([__('messages.error.action')])->withInput($request->all());
        }

        $entity = new Deposit;
        $entity->fill($request->all());
        $entity->payment_method = 'custom';

        $created = $entity->save();

        if($request->post('method_submit') == 'next')
        {
            return redirect(route('dash.deposits.index') . '/' . $entity->id . '/edit')->with('success', __('messages.created'));
        }
        return redirect()->route('dash.deposits.index')->with('success', __('messages.created'));
    }


    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Deposit  $deposit
     * @return \Illuminate\Http\Response
     */
    public function edit(Deposit $deposit)
    {
        view()->share('site_title', 'Редактирование пополнения');

        Blade::include('_managers.form.input', 'formElement');
        $entity = $deposit;

        $paidSelect = [];
        if(!$entity->paid)
        {
            $paidSelect[] = ['id' => 0, 'label' => 'Ожидает оплаты'];
        }
        $paidSelect[] = ['id' => 1, 'label' => 'Оплачен'];
        view()->share('select_paid', $paidSelect);

        return view('_managers.deposits.edit', compact('entity'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Deposit  $deposit
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Deposit $deposit)
    {
        $updateData = $request->validate([
            //'user_id'        => 'required|numeric',
            'payment_total'  => 'required|numeric',
            'payment_method' => 'required',
            'paid'           => 'required'
        ]);

        $saveFields = $request->all();


        /*
         * Загружаем данные пользователя
         */
        if($deposit->paid == 0 && $request->get('paid') == 1)
        {
            $user = User::find($deposit->user_id);
            if(!$user)
            {
                return back()->withErrors([__('messages.error.action')])->withInput($request->all());
            }
            $balancePlus = $user->changeBalance('plus', $request->get('payment_total'));
            if(!$balancePlus['status'])
            {
                return back()->withErrors([__('messages.error.action')])->withInput($request->all());
            }
        }

        $result = Deposit::findOrFail($deposit->id)->update($saveFields);

        $returnMessage = 'ID:' . $deposit->id . ' ' . __('messages.updated');
        if($request->post('method_submit') == 'next')
        {
            return redirect(route('dash.deposits.index') . '/' . $deposit->id . '/edit')->with('success', $returnMessage);
        }
        return redirect()->route('dash.deposits.index')->with('success', $returnMessage);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Deposit  $deposit
     * @return \Illuminate\Http\Response
     */
    public function destroy($ids, Request $request)
    {
        $ids = explode(',', $ids);
        $count = Deposit::destroy($ids);

        // Возвращаем ошибку, если удаленных записей 0
        if(!$count)
        {
            if($request->ajax()){
                return response()->json([
                    'status' => true,
                    'notify' => [
                        'type'   => 'danger',
                        'icon'   => 'oi oi-check',
                        'title'  => __('messages.error.action'),
                        'text'   => __('messages.deleted_error')
                    ]
                ]);
            }
            return redirect()->route('dash.deposits.index')->with('success', __('messages.deleted_error'));
        }

        // Возвращаем сообщение о выполнении удаления
        if($request->ajax()){
            return response()->json([
                'status' => true,
                'notify' => [
                    'type'   => 'info',
                    'icon'   => 'oi oi-check',
                    'title'  => __('messages.success.action'),
                    'text'   => trans('messages.deleteds', ['count' => $count])
                ]
            ]);
        }
        return redirect()->route('dash.deposits.index')->with('success', trans('messages.deleteds', ['count' => $count]));
    }
}
