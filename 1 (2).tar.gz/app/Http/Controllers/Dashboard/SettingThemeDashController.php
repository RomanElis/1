<?php

namespace App\Http\Controllers\Dashboard;

use App\Models\Dashboard\SettingDash;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Blade;
use Illuminate\Support\Facades\Config;

class SettingThemeDashController extends Controller
{
    public function index($page = 0)
    {
        $getOptions = Config::get('settings_themes');

        view()->share('site_title', 'Настройки шаблона');

        Blade::include('_managers.form.input', 'formElement');
        return view('_managers.settings_themes', ['themes' => $getOptions]);
    }

    public function update(Request $request)
    {
        // Сверяем от куда пришли данные
        if(url()->previous() != route('dash.settings.themes.index')){echo 'Error save'; exit;}

        $themes = $request->input('themes');
        SettingDash::setOptionsByFile($themes, 'settings_themes');
        //SettingDash::setOptions($themes);

        $return = redirect()->route('dash.settings.themes.index')->with('success', __('messages.updated'));;

        $exitCode = Artisan::call('config:cache');

        return $return;
    }


    public function payments_index($page = 0)
    {
        $getOptions = Config::get('themes');

        view()->share('site_title', 'Настройки платежных систем');

        Blade::include('_managers.form.input', 'formElement');
        return view('_managers.themes', ['themes' => $getOptions]);
    }
}
