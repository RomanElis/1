<?php

namespace App\Http\Controllers\Dashboard;

use App\Helpers\Helpers;
use App\Http\Controllers\Controller;
use App\Models\Dashboard\ExportToFile;
use App\Models\Deposit;
use App\Models\Purchase;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Blade;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

class UserDashController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        if($request->post('export') == 'csv')
        {
            return (new ExportToFile())->loadModel('User')->exportCsv();
        }

        $order = $request->get('order') ?? 'asc';
        $orderBy = $request->get('orderby') ?? 'id';

        $where = $request->get('where');
        $search = $request->get('search');

        $modelLoad = new User;
        $model = $modelLoad->orderBy($orderBy, $order);
        $model->withCount([
            'purchase',
            'purchase as purchase_count' => function ($query) {
                $query->where('paid', '=', 1);
        }]);
        // dd($model->get()->toArray());

        if(!empty($where) && !empty(!empty($search)))
        {
            if(in_array($where, ['title', 'email']))
            {
                $model->where($where, 'LIKE', '%' . $search . '%');
            }
        }

        if($date_range = Helpers::dateRange($request->get('date_range'))) {
            $model->whereBetween(DB::raw('DATE(created_at)'), $date_range);
        }

        if($group = $request->get('group'))
        {
            $model->where('group', '=', $group);
        }

        $count = $model->count();
        $items = $model->paginate(20);

        $items->withQueryString();


        view()->share('site_title', 'Список пользователей');

        view()->share('field_allow_sort', [
            ['value' => 'name', 'label' => 'По имени'],
            ['value' => 'email', 'label' => 'По email']
        ]);


        $tabsItems = $modelLoad->getFilterLinks();
        if($tabsItems)
        {
            $filter_links = [
                [
                    'href'  => route('dash.users.index'),
                    'label' => 'Все',
                    'count' => $tabsItems['all'],
                    'current' => ($request->get('group', 'all') == 'all') ? true : false
                ],
                [
                    'href'  => route('dash.users.index', ['group' => 'admin']),
                    'label' => 'Администраторы',
                    'count' => isset($tabsItems['admin']) ? $tabsItems['admin'] : 0,
                    'current' => $request->get('group') == 'admin' ? true : false
                ],
                [
                    'href'  => route('dash.users.index', ['group' => 'user']),
                    'label' => 'Пользователи',
                    'count' => isset($tabsItems['user']) ? $tabsItems['user'] : 0,
                    'current' => $request->get('group') == 'user' ? true : false
                ]
            ];
            view()->share('filter_links', $filter_links);
        }

        view()->share('filter_hidefield', [
            'group' => $request->get('group')
        ]);

        Blade::include('_managers.form.input', 'formElement');
        return view('_managers.crud.table', [
            'route_entity_update'      => false,
            'controller_name' => substr(get_class($this), strrpos(get_class($this), '\\') + 1),
            'items'         => $items,
            'count'         => $count,
            'param_orderby' => $orderBy,
            'cruds'         => $modelLoad->cruds()
        ]);

//        return view('_managers.users.index', [
//            'items'         => $items,
//            'count'         => $count,
//            'param_orderby' => $orderBy
//        ]);
    }


    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        view()->share('site_title', 'Создать пользователя');

        $modelUser = new User;
        $group_items = $modelUser->getGroupItems();
        view()->share('group_items', $group_items);

        Blade::include('_managers.form.input', 'formElement');
        return view('_managers.users.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request, [
            'name'  => 'required',
            'email' => 'required|unique:users',
            'group' => 'required',
            'password'  => ['required', 'string', 'min:8', 'confirmed']
        ]);

        $saveFields = $request->all();
        $saveFields['password'] = Hash::make($request->password);

        $user = new User;
        $user->fill($saveFields);

        $user->save();


        if($request->post('method_submit') == 'next')
        {
            return redirect(route('dash.users.index') . '/' . $user->id . '/edit')->with('success', __('messages.created'));
        }

        return redirect()->route('dash.users.index')->with('success', __('messages.created'));
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\User  $user
     * @return \Illuminate\Http\Response
     */
    public function show(User $user)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\User  $user
     * @return \Illuminate\Http\Response
     */
    public function edit(User $user)
    {
        $user->purchase_count = Purchase::where('paid', '=', '1')->where('user_id', '=', $user->id)->get()->count();
        $user->deposit_count = Deposit::where('paid', '=', '1')->where('user_id', '=', $user->id)->get()->count();


        view()->share('site_title', 'Редактирование пользователя');

        Blade::include('_managers.form.input', 'formElement');

        $group_items = $user->getGroupItems();
        view()->share('group_items', $group_items);

        return view('_managers.users.edit',compact('user'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\User  $user
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, User $user)
    {
        $validateItems = [
            'name'     => 'required',
            'email'    => 'required|unique:users,email,' . $user->id,
            'group'    => 'required',
        ];
        if(!empty($request->password))
        {
            $validateItems['password'] = 'required|confirmed|min:6';
        }
        $updateData = $request->validate($validateItems);

        $saveFields = $request->all();

        if(!empty($request->password))
        {
            $saveFields['password'] = Hash::make($request->password);
        }
        else
        {
            unset($saveFields['password']);
        }


        if(!($request->post('balance_update') == 'allow'))
        {
            unset($saveFields['balance']);
        }


        // User::find(auth()->user()->id)
        $result = $user->update($saveFields);
        //User::findOrFail($user->id)->update($updateData);

        //User::findOrFail($user->id)->update($updateData);

        $returnMassage = 'ID:' . $user->id . ' ' . __('messages.updated');
        if($request->post('method_submit') == 'next')
        {
            return redirect(route('dash.users.index') . '/' . $user->id . '/edit')->with('success', $returnMassage);
        }
        return redirect()->route('dash.users.index')->with('success', $returnMassage);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\User  $user
     * @return \Illuminate\Http\Response
     */
    public function destroy($ids, Request $request)
    {
        $ids = explode(',', $ids);
        $count = User::destroy($ids);

        // Возвращаем ошибку, если удаленных записей 0
        if(!$count)
        {
            if($request->ajax()){
                return response()->json([
                    'status' => true,
                    'notify' => [
                        'type'   => 'danger',
                        'icon'   => 'oi oi-check',
                        'title'  => __('messages.error.action'),
                        'text'   => __('messages.deleted_error')
                    ]
                ]);
            }
            return redirect()->route('dash.users.index')->with('success', __('messages.deleted_error'));
        }

        // Возвращаем сообщение о выполнении удаления
        if($request->ajax()){
            return response()->json([
                'status' => true,
                'notify' => [
                    'type'   => 'info',
                    'icon'   => 'oi oi-check',
                    'title'  => __('messages.success.action'),
                    'text'   => trans('messages.deleteds', ['count' => $count])
                ]
            ]);
        }
        return redirect()->route('dash.users.index')->with('success', trans('messages.deleteds', ['count' => $count]));
    }
}
