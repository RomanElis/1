<?php

namespace App\Http\Controllers\Dashboard;

use App\Helpers\Helpers;
use App\Http\Controllers\Controller;
use App\Models\Dashboard\ExportToFile;
use App\Models\Page;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Blade;
use Illuminate\Support\Facades\DB;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Support\Str;

class PageDashController extends Controller
{
    use ValidatesRequests;
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        if($request->post('export') == 'csv')
        {
            return (new ExportToFile())->loadModel('Page')->exportCsv();
        }

        $order = $request->get('order') ?? 'asc';
        $orderBy = $request->get('orderby') ?? 'id';

        $where = $request->get('where');
        $search = $request->get('search');

        $modelLoad = new Page;
        $model = $modelLoad->orderBy($orderBy, $order);

        if(!empty($where) && !empty(!empty($search)))
        {
            if(in_array($where, ['title']))
            {
                $model->where($where, 'LIKE', '%' . $search . '%');
            }
        }


        if($date_range = Helpers::dateRange($request->get('date_range'))) {
            $model->whereBetween(DB::raw('DATE(created_at)'), $date_range);
        }


        $count = $model->count();
        $items = $model->paginate(20);

        $items->withQueryString();

        view()->share('site_title', 'Список страниц');

        view()->share('field_allow_sort', [
            ['value' => 'title', 'label' => 'По заголовку']
        ]);

        Blade::include('_managers.form.input', 'formElement');

        return view('_managers.crud.table', [
            'route_entity_update'      => route('dash.pages.update.entity'),
            'controller_name' => substr(get_class($this), strrpos(get_class($this), '\\') + 1),
            'items'         => $items,
            'count'         => $count,
            'param_orderby' => $orderBy,
            'cruds'         => $modelLoad->cruds()
        ]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
        view()->share('site_title', 'Создать страницу');

        Blade::include('_managers.form.input', 'formElement');
        return view('_managers.pages.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $updateData = $this->validate($request, [
            'slug'        => 'unique:pages',
            'title'       => 'required'
        ]);

        // $validated['slug'] = Str::slug($validated['title'], '-');

        $page = new Page();
        $page->fill($request->all());

        if(!isset($updateData['slug']))
        {
            $slug = Str::slug($updateData['title'], '-');
            $count = Page::whereRaw("slug RLIKE '^{$slug}(-[0-9]+)?$'")->count();
            $page->slug = $count ? "{$slug}-{$count}" : $slug;
        }

        if(!$page->slug)
        {
            $page->slug = Str::slug($page->title, '-');
        }

        $created = $page->save();

        if($request->post('method_submit') == 'next')
        {
            return redirect(route('dash.pages.index') . '/' . $page->id . '/edit')->with('success', __('messages.created'));
        }
        return redirect()->route('dash.pages.index')->with('success', __('messages.created'));
    }


    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Page  $pages
     * @return \Illuminate\Http\Response
     */
    public function edit(Page $page, $id = false)
    {
        view()->share('site_title', 'Редактирование страницы');

        Blade::include('_managers.form.input', 'formElement');
        return view('_managers.pages.edit',compact('page'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Page  $pages
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Page $page)
    {
        $updateData = $request->validate([
            'slug'        => 'unique:pages,slug,' . $page->id,
            'title'       => 'required'
        ]);

        $saveFields = $request->all();

        if(!isset($updateData['slug']))
        {
            $slug = Str::slug($updateData['title'], '-');
            $count = Page::whereRaw("slug RLIKE '^{$slug}(-[0-9]+)?$'")->count();
            $saveFields['slug'] = $count ? "{$slug}-{$count}" : $slug;
        }

        $result = Page::findOrFail($page->id)->update($saveFields);

        $returnMessage = 'ID:' . $page->id . ' ' . __('messages.updated');
        if($request->post('method_submit') == 'next')
        {
            return redirect(route('dash.pages.index') . '/' . $page->id . '/edit')->with('success', $returnMessage);
        }
        return redirect()->route('dash.pages.index')->with('success', $returnMessage);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Page  $pages
     * @return \Illuminate\Http\Response
     */
    public function destroy($ids, Request $request)
    {

        $ids = explode(',', $ids);
        $count = Page::destroy($ids);

        // Возвращаем ошибку, если удаленных записей 0
        if(!$count)
        {
            if($request->ajax()){
                return response()->json([
                    'status' => true,
                    'notify' => [
                        'type'   => 'danger',
                        'icon'   => 'oi oi-check',
                        'title'  => __('messages.error.action'),
                        'text'   => __('messages.deleted_error')
                    ]
                ]);
            }
            return redirect()->route('dash.pages.index')->with('success', __('messages.deleted_error'));
        }

        // Возвращаем сообщение о выполнении удаления
        if($request->ajax()){
            return response()->json([
                'status' => true,
                'notify' => [
                    'type'   => 'info',
                    'icon'   => 'oi oi-check',
                    'title'  => __('messages.success.action'),
                    'text'   => trans('messages.deleteds', ['count' => $count])
                ]
            ]);
        }
        return redirect()->route('dash.pages.index')->with('success', trans('messages.deleteds', ['count' => $count]));
    }

    // Обновление сущностей товаров
    public function updateEntity(Request $request)
    {
        $count = 0;

        // Извлекаем данные
        $items = $request->post('items');
        if($items && count($items))
        {
            foreach($items as $id=>$data)
            {
                $modelProduct = Page::find($id);
                if(!$modelProduct)
                {
                    return redirect()->back()->with('success', trans('messages.updates', ['count' => $count]));
                }

                $dataUpdate = [];

                $activity = isset($data['activity']) && $data['activity'] ? 1 : 0;
                if($modelProduct->activity != $activity)
                {
                    $dataUpdate['activity'] = $activity;
                }

                if(count($dataUpdate) && $modelProduct->update($dataUpdate))
                {
                    $count++;
                }
            }
        }
        return redirect()->back()->with('success', trans('messages.updates', ['count' => $count]));
    }
}
