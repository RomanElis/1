<?php

namespace App\Http\Controllers\Dashboard;

use App\Helpers\Helpers;
use App\Http\Controllers\Controller;
use App\Models\Dashboard\ExportToFile;
use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Blade;
use Illuminate\Support\Facades\DB;

class ProductDashController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {

        if($request->post('export') == 'csv')
        {
            return (new ExportToFile())->loadModel('Product')->exportCsv();
        }

        $order = $request->get('order') ?? 'asc';
        $orderBy = $request->get('orderby') ?? 'position';

        $where = $request->get('where');
        $search = $request->get('search');

        $modelLoad = new Product;
        $model = $modelLoad->orderBy($orderBy, $order);

        if(!empty($where) && !empty(!empty($search)))
        {
            if(in_array($where, ['title']))
            {
                $model->where($where, 'LIKE', '%' . $search . '%');
            }
            if(in_array($where, ['id']))
            {
                $model->where($where, '=', $search);
            }
            if(in_array($where, ['in_id']))
            {
                $search = explode(',', $search);
                if(count($search) >= 1)
                {
                    $model->whereIn(mb_substr($where, 3), $search);
                }
            }
        }


        if($date_range = Helpers::dateRange($request->get('date_range'))) {
            $model->whereBetween(DB::raw('DATE(created_at)'), $date_range);
        }

        $count = $model->count();
        $items = $model->paginate(1000);

        $items->withQueryString();

        view()->share('site_title', 'Список товаров');

        view()->share('field_allow_sort', [
            ['value' => 'title', 'label' => 'По заголовку'],
            ['value' => 'id', 'label' => 'По идентификатору'],
            ['value' => 'in_id', 'label' => 'По идентификаторам']
        ]);


        $cruds = $modelLoad->cruds();
        if($request->get('where'))
        {
            unset($cruds['items']['sorttable']);
        }

        Blade::include('_managers.form.input', 'formElement');

        return view('_managers.crud.table', [
            'route_entity_update'      => route('dash.products.update.entity'),
            'controller_name' => substr(get_class($this), strrpos(get_class($this), '\\') + 1),
            'items'           => $items,
            'count'           => $count,
            'param_orderby'   => $orderBy,
            'cruds'           => $cruds
        ]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Product $product, Request $request)
    {
        view()->share('site_title', 'Создать товар');

        if($request->get('settype') == 'header')
        {
            view()->share('site_title', 'Создать заголовок');
        }
        if($request->get('settype') == 'subheader')
        {
            view()->share('site_title', 'Создать подзаголовок');
        }

        view()->share('type_items', $product->getTypeItems());

        Blade::include('_managers.form.input', 'formElement');
        return view('_managers.products.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request, [
            'title'       => 'required',
            'price'       => 'numeric',
            'goods_file' => 'mimes:txt|max:2048'
        ]);

        $entity = new Product();
        $entity->fill($request->all());

        /*
         * Загружаем файл, разбираем файл на строки и добавляем в бд
         */
        $fileGoods = $request->file('goods_file');
        if(!empty($fileGoods))
        {
            $goodsFileToSave = $entity->goodsFileToSave($fileGoods->getRealPath());
            $entity->goods = $goodsFileToSave->goods;
            $entity->stock = $goodsFileToSave->stock;
        }

        /*
         * Добавляем товар
         */
        $created = $entity->save();

        if($request->post('method_submit') == 'next')
        {
            return redirect(route('dash.products.index') . '/' . $entity->id . '/edit')->with('success', __('messages.created'));
        }
        return redirect()->route('dash.products.index')->with('success', __('messages.created'));
    }


    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function edit(Product $product)
    {
        view()->share('site_title', 'Редактирование товара');

        view()->share('type_items', $product->getTypeItems());

        Blade::include('_managers.form.input', 'formElement');
        return view('_managers.products.edit',compact('product'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Product $product)
    {
        $updateData = $request->validate([
            'title'       => 'required',
            'price'       => 'numeric',
            'goods_file' => 'mimes:txt|max:2048'
        ]);

        $saveFields = $request->all();

        /*
         * Загружаем файл, разбираем файл на строки и добавляем в бд
         */
        $fileGoods = $request->file('goods_file');
        if(!empty($fileGoods))
        {
            $goodsFileToSave = $product->goodsFileToSave($fileGoods->getRealPath());
            $saveFields['goods'] = $goodsFileToSave->goods;
            $saveFields['stock'] = $goodsFileToSave->stock;
        }
        if($request->get('goods_file_empty') == 'remove')
        {
            $saveFields['goods'] = '';
            $saveFields['stock'] = 0;
        }

        /*
         * Ищем товар и обновляем
         */
        $result = Product::findOrFail($product->id)->update($saveFields);

        $returnMassage = 'ID:' . $product->id . ' ' . __('messages.updated');
        if($request->post('method_submit') == 'next')
        {
            return redirect(route('dash.products.index') . '/' . $product->id . '/edit')->with('success', $returnMassage);
        }
        return redirect()->route('dash.products.index')->with('success', $returnMassage);
    }


    public function goodsUpload(Request $request, Product $product)
    {
        $updateData = $request->validate([
            'goods_file' => 'mimes:txt|max:2048'
        ]);

        $saveFields = $request->all();

        $fileGoods = $request->file('goods_file');
        if(!empty($fileGoods))
        {
            $goodsFileToSave = $product->goodsFileToSave($fileGoods->getRealPath());
            $saveFields['goods'] = $goodsFileToSave->goods;
            $saveFields['stock'] = $goodsFileToSave->stock;
        }

        $result = Product::findOrFail($product->id)->update($saveFields);

        $returnMassage = 'ID:' . $product->id . ' ' . __('messages.updated');

        return response()->json([
            'entity_id' => $product->id,
            'rereplace' => ['stock' => $saveFields['stock']],
            'status' => true,
            'notify' => [
                'type'   => 'info',
                'icon'   => 'oi oi-check',
                'title'  => __('messages.success.action'),
                'text'   => trans('messages.upload_goods_success', ['count' => $saveFields['stock']])
            ]
        ]);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function destroy($ids, Request $request)
    {
        $ids = explode(',', $ids);
        $count = Product::destroy($ids);

        // Возвращаем ошибку, если удаленных записей 0
        if(!$count)
        {
            if($request->ajax()){
                return response()->json([
                    'status' => true,
                    'notify' => [
                        'type'   => 'danger',
                        'icon'   => 'oi oi-check',
                        'title'  => __('messages.error.action'),
                        'text'   => __('messages.deleted_error')
                    ]
                ]);
            }
            return redirect()->route('dash.products.index')->with('success', __('messages.deleted_error'));
        }

        // Возвращаем сообщение о выполнении удаления
        if($request->ajax()){
            return response()->json([
                'status' => true,
                'notify' => [
                    'type'   => 'info',
                    'icon'   => 'oi oi-check',
                    'title'  => __('messages.success.action'),
                    'text'   => trans('messages.deleteds', ['count' => $count])
                ]
            ]);
        }
        return redirect()->route('dash.products.index')->with('success', trans('messages.deleteds', ['count' => $count]));
    }


    // Скачивание товар-файла
    public function goodsDownload(Request $request, Product $product)
    {
        return $product->downloadFileTxt($product->goods, 'goods-id-' . $product->id);
    }

    // Обновление позиций товаров
    public function updatePosition(Request $request)
    {
        $indx = 0;
        $count = 0;

        // Сортировка
        $positions = $request->post('items');
        if(count($positions))
        {
            foreach($positions as $pos=>$id)
            {
                if(Product::findOrFail($id)->update(['position'=>($pos + $indx)]))
                {
                    $count++;
                    $indx = $indx + 10;
                }
            }
        }

        return response()->json([
            'status' => true,
            'notify' => [
                'type'   => 'info',
                'icon'   => 'oi oi-check',
                'title'  => __('messages.success.action'),
                'text'   => trans('messages.updates', ['count' => $count])
            ]
        ]);
    }

    // Обновление сущностей товаров
    public function updateEntity(Request $request)
    {
        $count = 0;

        // Извлекаем данные
        $items = $request->post('items');
        if($items && count($items))
        {
            foreach($items as $id=>$data)
            {
//                if(!count(array_intersect(['price', 'activity'], array_flip($data)))){
//                    continue;
//                }

                $modelProduct = Product::find($id);
                if(!$modelProduct)
                {
                    return redirect()->back()->with('success', trans('messages.updates', ['count' => $count]));
                }

                $dataUpdate = [];

                $activity = isset($data['activity']) && $data['activity'] ? 1 : 0;
                if($modelProduct->activity != $activity)
                {
                    $dataUpdate['activity'] = $activity;
                }

                if(isset($data['price']) && $modelProduct->price != $data['price'])
                {
                    $dataUpdate['price'] = $data['price'];
                }

                if(count($dataUpdate) && $modelProduct->update($dataUpdate))
                {
                    $count++;
                }
            }
        }
        return redirect()->back()->with('success', trans('messages.updates', ['count' => $count]));
    }
}
