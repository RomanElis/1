<?php

namespace App\Http\Controllers\Dashboard;

use App\Helpers\Helpers;
use App\Http\Controllers\Controller;
use App\Models\Dashboard\ExportToFile;
use App\Models\Paid;
use App\Models\Product;
use App\Models\Purchase;
use App\Models\SystemPayment\SystemPayment;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Blade;
use Illuminate\Support\Facades\DB;

class PurchaseDashController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {

        if($request->post('export') == 'csv')
        {
            return (new ExportToFile())->loadModel('Purchase')->exportCsv();
        }

        if($request->get('test')) { DB::enableQueryLog(); };

        $order = $request->get('order') ?? 'desc';
        $orderBy = $request->get('orderby') ?? 'id';
        $orderBy = 'purchases.' . $orderBy;

        $where = $request->get('where');
        $search = $request->get('search');

        $modelLoad = new Purchase;
        $model = $modelLoad->orderBy($orderBy, $order);

        $model->with('user');
        //$model->with('product');
        $model->with('paid_data');

        if($date_range = Helpers::dateRange($request->get('date_range'))) {
             $model->whereBetween(DB::raw('DATE(created_at)'), $date_range);
        }


        if(!empty($where) && !empty(!empty($search)))
        {
            if(in_array($where, ['title', 'user_email']))
            {
                $model->where($where, 'LIKE', '%' . $search . '%');
            }
            if(in_array($where, ['id', 'user_id']))
            {
                $model->where($where, '=', $search);
            }
            if(in_array($where, ['paid_data_by_id', 'user_by_name', 'user_by_email']))
            {
                $whereEx = explode('_by_', $where);
                $model->whereHas($whereEx[0], function($query) use ($whereEx, $search) {
                    $query->where($whereEx[1], 'LIKE', '%' . $search . '%');
                });
            }
        }

        $paidStatus = $request->get('paid', '1');
        if($paidStatus != 'all' && in_array($paidStatus, [0, 1]))
        {
            $model->where('paid', '=', $paidStatus);
        }

        $items = $model->paginate(50);
        $count = $items->total();

        $items->withQueryString();


        if($request->get('test')) { dd(DB::getQueryLog()); };


        view()->share('site_title', 'Список заказов');

        view()->share('field_allow_sort', [
            ['value' => 'id', 'label' => 'По id заказа'],
            ['value' => 'paid_data_by_id', 'label' => 'По платежному ID'],
            ['value' => 'user_email', 'label' => 'По email заказа'],
            ['value' => 'user_id', 'label' => 'По id пользователя'],
            ['value' => 'user_by_name', 'label' => 'По имени клиента'],
            ['value' => 'user_by_email', 'label' => 'По email клиента']
        ]);


        $tabsItems = $modelLoad->getFilterLinks();
        if($tabsItems)
        {
            $filter_links = [
                [
                    'href'    => route('dash.purchases.index', ['paid' => 'all']),
                    'label'   => 'Все',
                    'count'   => $tabsItems['all'],
                    'current' => $request->get('paid') == 'all' ? true : false
                ],
                [
                    'href'    => route('dash.purchases.index', ['paid' => '1']),
                    'label'   => 'Оплаченные',
                    'count'   => isset($tabsItems['1']) ? $tabsItems['1'] : 0,
                    'current' => ($request->get('paid', '1') == '1') ? true : false
                ],
                [
                    'href'    => route('dash.purchases.index', ['paid' => '0']),
                    'label'   => 'Ожидают оплаты (временные)',
                    'count'   => isset($tabsItems['0']) ? $tabsItems['0'] : 0,
                    'current' => $request->get('paid') == '0' ? true : false
                ]
            ];
            view()->share('filter_links', $filter_links);
        }


        Blade::include('_managers.form.input', 'formElement');
        return view('_managers.crud.table', [
            'route_entity_update'      => false,
            'controller_name' => substr(get_class($this), strrpos(get_class($this), '\\') + 1),
            'items'           => $items,
            'count'           => $count,
            'param_orderby'   => $orderBy,
            'cruds'           => $modelLoad->cruds()
        ]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        view()->share('site_title', 'Создать');

        $systemPayment = new SystemPayment;
        $systemPaymentItems = $systemPayment->getSystems()->whereActivity()->items();
        $systemPaymentSelect = [];
        foreach ($systemPaymentItems as $systemPaymentItem) {
            $systemPaymentSelect[] = [
                'id' => $systemPaymentItem['id'],
                'label' => $systemPaymentItem['name']
            ];
        }
        view()->share('systems_payments', $systemPaymentSelect);

        Blade::include('_managers.form.input', 'formElement');
        return view('_managers.purchases.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request, [
            'user_id'        => 'required|exists:App\Models\User,id',
            'product_id'     => 'required',
            'quantity'       => 'required',
            'payment_total'  => 'required|numeric',
            'payment_method' => 'required',
            'paid'           => 'required'
        ]);


        /*
         * Загружаем товар
         */
        if(!$request->get('product_title') && $request->get('product_id'))
        {
            $product = Product::find($request->get('product_id'));
            if(!$product)
            {
                // Err
                return back()->withErrors([__('messages.error.product')]);
            }
        }

        $entity = new Purchase;
        $entity->fill($request->all());

        if(isset($product->title) && !empty($product->title))
        {
            $entity->product_title = $product->title;
        }

        $created = $entity->save();


        /*
         * Создаем чек/проверку оплаты
         */
        $createdSlug = sha1($entity->product_id . $entity->price . $entity->quantity . $entity->payment_total . time());
        $paid = new Paid;
        $paid->attach_id = $entity->id;
        $paid->slug = $createdSlug;
        $paid->type = 'Purchase';
        $paidCreate = $paid->save();
        if(!$paidCreate)
        {
            return back()->withErrors([__('messages.error.action')]);
        }

        $returnMessage = 'ID:' . $entity->id . ' ' . __('messages.updated');
        if($request->post('method_submit') == 'next')
        {
            return redirect(route('dash.purchases.index') . '/' . $entity->id . '/edit')->with('success', $returnMessage);
        }
        return redirect()->route('dash.purchases.index')->with('success', $returnMessage);
    }


    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Purchase  $purchase
     * @return \Illuminate\Http\Response
     */
    public function edit(Purchase $purchase)
    {
        view()->share('site_title', 'Редактирование заказа');

        Blade::include('_managers.form.input', 'formElement');
        $entity = $purchase;
        return view('_managers.purchases.edit',compact('entity'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Purchase  $purchase
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Purchase $purchase)
    {
        $updateData = $request->validate([
            'user_id'        => 'required',
            'product_id'     => 'required',
            'product_title'  => 'required',
            'quantity'       => 'required',
            'payment_total'  => 'required|numeric',
            'payment_method' => 'required',
            'paid'           => 'required'
        ]);

        $saveFields = $request->all();

        $fileGoods = $request->file('goods_file');
        if(!empty($fileGoods))
        {
            $goodsFileToSave = $purchase->goodsFileToSave($fileGoods->getRealPath());
            $saveFields['goods'] = $goodsFileToSave->goods;
            // $saveFields['stock'] = $goodsFileToSave->stock;
        }

        if($request->get('goods_file_empty') == 'remove')
        {
            $saveFields['goods'] = '';
        }

        $result = $purchase->update($saveFields);
        // $result = Purchase::findOrFail($purchase->id)->update($saveFields);

        $returnMessage = 'ID:' . $purchase->id . ' ' . __('messages.updated');
        if($request->post('method_submit') == 'next')
        {
            return redirect(route('dash.purchases.index') . '/' . $purchase->id . '/edit')->with('success', $returnMessage);
        }
        return redirect()->route('dash.purchases.index')->with('success', $returnMessage);
    }


    public function goodsUpload(Request $request, Purchase $purchase)
    {
        $updateData = $request->validate([
            'goods_file' => 'mimes:txt|max:2048'
        ]);

        $saveFields = $request->all();

        $fileGoods = $request->file('goods_file');
        if(!empty($fileGoods))
        {
            $goodsFileToSave = $purchase->goodsFileToSave($fileGoods->getRealPath());
            $saveFields['goods'] = $goodsFileToSave->goods;
            $saveFields['stock'] = $goodsFileToSave->stock;
        }

        $purchase->goods = $goodsFileToSave->goods;
        $result = $purchase->update($saveFields);

        $returnMassage = 'ID:' . $purchase->id . ' ' . __('messages.updated');

        return response()->json([
            'entity_id' => $purchase->id,
            'rereplace' => ['stock' => $saveFields['stock']],
            'status' => true,
            'notify' => [
                'type'   => 'info',
                'icon'   => 'oi oi-check',
                'title'  => __('messages.success.action'),
                'text'   => trans('messages.upload_goods_success', ['count' => $saveFields['stock']])
            ]
        ]);
    }

    // Скачивание товар-файла
    public function goodsDownload(Request $request, Purchase $purchase)
    {
        $product = new Product;
        return $product->downloadFileTxt($purchase->goods, 'goods-id-' . $purchase->id);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Purchase  $purchase
     * @return \Illuminate\Http\Response
     */
    public function destroy($ids, Request $request)
    {
        $ids = explode(',', $ids);
        $count = Purchase::destroy($ids);

        // Возвращаем ошибку, если удаленных записей 0
        if(!$count)
        {
            if($request->ajax()){
                return response()->json([
                    'status' => true,
                    'notify' => [
                        'type'   => 'danger',
                        'icon'   => 'oi oi-check',
                        'title'  => __('messages.error.action'),
                        'text'   => __('messages.deleted_error')
                    ]
                ]);
            }
            return redirect()->route('dash.products.index')->with('success', __('messages.deleted_error'));
        }

        // Возвращаем сообщение о выполнении удаления
        if($request->ajax()){
            return response()->json([
                'status' => true,
                'notify' => [
                    'type'   => 'info',
                    'icon'   => 'oi oi-check',
                    'title'  => __('messages.success.action'),
                    'text'   => trans('messages.deleteds', ['count' => $count])
                ]
            ]);
        }
        return redirect()->route('dash.products.index')->with('success', trans('messages.deleteds', ['count' => $count]));
    }
}
