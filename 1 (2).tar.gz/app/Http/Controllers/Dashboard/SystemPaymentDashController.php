<?php

namespace App\Http\Controllers\Dashboard;

use App\Http\Controllers\Controller;
use App\Models\Dashboard\SettingDash;
use App\Models\SystemPayment\SystemPayment;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Blade;
use Illuminate\Support\Facades\Config;

class SystemPaymentDashController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $getOptions = Config::get('system.payment');

        view()->share('site_title', 'Настройки платежных систем');

        $systemPayment = new SystemPayment;
        $systemPaymentItems = $systemPayment->getSystems()->items();

        $pathUrl = url('/');


        foreach ($systemPaymentItems as $systemPaymentName => $systemPaymentItem)
        {
            if(!isset($systemPaymentItem['callback'])) continue;
            foreach ($systemPaymentItem['callback'] as $sysName => $sysItem)
            {
                $systemPaymentItems[$systemPaymentName]['callback'][$sysName]['value'] = str_replace('%SITE_URL%', $pathUrl, $sysItem['value']);
            }
        }


        view()->share('systems', $systemPaymentItems);

        Blade::include('_managers.form.input', 'formElement');
        return view('_managers.system_payments', [
            'settings' => $getOptions
        ]);
    }


    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\SystemPayment\SystemPayment  $sysPayment
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, SystemPayment $sysPayment)
    {
        // Сверяем от куда пришли данные
        if(url()->previous() != route('dash.settings.system.payments.index')){echo 'Error save'; exit;}

        $settings = $request->input('settings');
        SettingDash::setOptionsByFile($settings, 'system.payment');

        //Config::set('settings.wysiwyg_editor', 'asassfsf');

        $return = redirect()->route('dash.settings.system.payments.index')->with('success', __('messages.updated'));;

        $exitCode = Artisan::call('config:cache');

        return $return;
    }

}
