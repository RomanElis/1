<?php

namespace App\Http\Controllers;

use App\Models\Deposit;
use App\Models\Product;
use App\Models\Purchase;
use App\Models\SystemPayment\SystemPayment;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

class UserController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        view()->share('site_title', 'Личный аккаунт');
        $currentUser = Auth::user();
        return view('auth.index',compact('currentUser'));
    }


    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\User  $user
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        $user = Auth::user();

        $validateItems = [
            //'name'     => 'required',
            //'email'    => 'required|unique:users,email,' . $user->id
        ];
        if(!empty($request->password))
        {
            $validateItems['password'] = 'required|confirmed|min:6';
        }
        $updateData = $request->validate($validateItems);

        $saveFields = $request->all();

        if(isset($saveFields['email'])) {
            unset($saveFields['email']);
        }
        if(isset($saveFields['name'])) {
            unset($saveFields['name']);
        }

        if(!empty($request->password))
        {
            $saveFields['password'] = Hash::make($request->password);
        }
        else
        {
            unset($saveFields['password']);
        }

        $result = $user->update($saveFields);

        $returnMessage = 'Ошибка обновления информации';
        if($result)
        {
            $returnMessage = 'Информация обновлена';
        }

        return redirect()->route('profile.index')->with('success', $returnMessage);
    }



    public function purchases_history()
    {
        view()->share('site_title', 'История покупок');
        $currentUser = Auth::user();

        $purchase = Purchase::where('user_id', $currentUser->id)->with('paid_data')->where('purchases.paid', 1)->orderBy('id', 'desc')->get();
        view()->share('purchases', count($purchase) >= 1 ? $purchase : false);
        //dd($purchase->toArray());

        return view('auth.purchases_history',compact('currentUser'));
    }


    public function deposits_history()
    {
        view()->share('site_title', 'История пополнений');
        $currentUser = Auth::user();

        $deposits = Deposit::where('user_id', $currentUser->id)->with('paid_data')->where('deposits.paid', 1)->orderBy('id', 'desc')->get();
        view()->share('deposits', count($deposits) >= 1 ? $deposits : false);

        return view('auth.deposits_history',compact('currentUser'));
    }


    public function addcash()
    {
        view()->share('site_title', 'Пополнить баланс');


        $systemPayment = new SystemPayment;
        $systemPaymentItems = $systemPayment->getSystems()->whereParam('method', 'callback')->whereActivity()->items();
        view()->share('systems_payments', $systemPaymentItems);

        $currentUser = Auth::user();
        return view('auth.addcash',compact('currentUser'));
    }


    public function favorite_show()
    {
        view()->share('site_title', 'Избранные товары');

    }


    public function favorite_update(Request $request)
    {
        $currentUser = Auth::user();
        if(!$currentUser) return response()->json(['status' => false]);
        $productId = (int)$request->get('id');

        $user = User::find($currentUser->id);
        if(!$user) return false;

        $getFav = explode(',', $user->favorites);

        if(in_array($productId, $getFav))
        {
            $getFav = array_diff( $getFav, [$productId] );
            $addFav = 'remove';
        }
        else
        {
            $modelProduct = Product::find($productId);
            if(!$modelProduct) return response()->json(['status' => false]);

            $getFav[] = $productId;
            $addFav = 'add';
        }

        $user->favorites = implode(',', array_unique($getFav));

        $user->save();

        return response()->json([
            'status'   => $addFav
        ]);
    }


}
