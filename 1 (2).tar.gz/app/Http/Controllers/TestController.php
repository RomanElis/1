<?php

namespace App\Http\Controllers;

use App\Models\Deposit;
use App\Models\Paid;
use App\Models\Purchase;
use App\Models\SystemPayment\SystemPayment;
use App\Models\Product;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Event;

class TestController extends Controller
{
    public function test(Request $request)
    {

//        $paid = new Paid;
//        $paid->delete_paids();
//        exit;

        abort(404, 'Страница не найдена!');

    }
}
