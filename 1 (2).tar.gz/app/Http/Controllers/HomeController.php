<?php

namespace App\Http\Controllers;

use App\Models\Product;
use App\Models\SystemPayment\SystemPayment;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Config;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        //$this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index(Request $request)
    {
        /*
         * Проверяем авторизацию
         */
        $userLogged = Auth::check();

        /*
         * Загружаем все товары
         */
        $products = Product::where('activity', 1);

        /*
         * Извлекаем избранные товары и фильтруем
         */
        if($userLogged)
        {
            $favorites = explode(',', Auth()->user()->favorites);
            if(count($favorites) >= 1 && $request->get('favorites') == 'show')
            {
                $products->where(function ($where) use($favorites){
                    $where->whereIn('id', $favorites);
                })->orWhere(function ($where){
                    $where->whereIn('type', ['subheader', 'header']);
                });
            }
        }

        /*
         * Извлекаем товары
         */
        $products = $products->orderBy('position', 'asc')->get();


        /*
         * Проставляем избранные товары
         */
        if($userLogged)
        {
            $products = collect($products)->map(function ($item, $key) use ($favorites) {
                if(in_array($item->id, $favorites)) $item->user_fav = true;
                return $item;
            })->all();
        }


        view()->share('products', $products);


        $systemPayment = new SystemPayment;
        $systemPaymentItems = $systemPayment->getSystems()->whereActivity()->items();
        $systemPaymentItemsFilter = collect($systemPaymentItems)->reject(function ($value, $key) use($userLogged) {
            if(!$userLogged && isset($value['method']) && $value['method'] == 'local')
            {
                return true;
            }
            return false;
        });
        view()->share('systems_payments', $systemPaymentItemsFilter);

        $config = Config::get('settings');

        view()->share('site_title', $config['meta']['title']);
        view()->share('meta', [
            'title'       => $config['meta']['title'],
            'description' => $config['meta']['description'],
            'keywords'     => $config['meta']['keywords']
        ]);

        return view('homepage');
    }
}
