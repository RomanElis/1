<?php

namespace App\Http\Controllers;

use App\Models\Paid;
use App\Models\Product;
use App\Models\Purchase;
use App\Models\SystemPayment\SystemPayment;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class PurchaseController extends Controller
{
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request, [
            'product_id' => 'required',
            'quantity'   => 'required|min:1', // numeric|
            'payment'    => 'required',
            'email'      => 'required|email'
        ]);

        /*
         * Загружаем данные пользователя
         */
        $currentUserData = null;
        $currentUserId = 0;
        if(Auth::check())
        {
            $currentUserData = Auth::user();
            $currentUserId = $currentUserData->id;
        }
        elseif($currentUserData = User::where('email', $request->post('email'))->first())
        {
            $currentUserId = $currentUserData->id;
        }


        /*
         * Создаем заказ
         */
        $paramsPayment = explode('--', $request->post('payment'));
        $paramsPaymentMain = array_pop($paramsPayment);
        $paramsPaymentSub = array_pop($paramsPayment);

        $payment = new Paid;
        $createPay = $payment->createPay([
            'product_id' => $request->post('product_id'),
            'quantity'   => $request->post('quantity'),
            'payment'    => $paramsPaymentMain,
            'subsystem'  => $paramsPaymentSub,
            'user_id'    => $currentUserId,
            'user'  => $currentUserData,
            'email'      => $request->post('email'),
        ]);

       // dd($createPay);

        $jsonData = [
            'data' => [
                'type'    => $createPay['status'],
                'message' => $createPay['info']
            ],
            'pay_id' => $createPay['create_id'],
            'pay_slug' => $createPay['create_slug'],
            'pay'    => $createPay['pay']
        ];


        return $jsonData;
    }

}
