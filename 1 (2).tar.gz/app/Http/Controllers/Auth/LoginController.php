<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Providers\RouteServiceProvider;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Config;

class LoginController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Login Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles authenticating users for the application and
    | redirecting them to your home screen. The controller uses a trait
    | to conveniently provide its functionality to your applications.
    |
    */

    use AuthenticatesUsers;

    /**
     * Where to redirect users after login.
     *
     * @var string
     */
    protected $redirectTo = RouteServiceProvider::HOME;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest')->except('logout');
    }

    /*
     * Записываем дату последней авторизации
     */
    public function authenticated(Request $request, $user) {

        /*
         * Проверяем, если аккаунт забанен, то предотвращаем авторизацию
         */
        if($user->group == 'ban')
        {
            $this->logout($request);
            return redirect()->route('homepage')->withErrors(['Account is banned']);
        }

        /*
         * Делаем отметку даты авторизации
         */
        $user->last_login = Carbon::now()->toDateTimeString();
        $user->save();




        if($user->group == 'admin' && Config::get('settings.dashboard_key') && !(Config::get('settings.dashboard_key') == $request->post('key')))
        {
            $this->logout($request);
            return redirect()->back()->withErrors([__('messages.dashboard_access_denied')]);
        }
        if($user->group == 'admin')
        {
            return redirect()->route('dash.index');
        }

    }
}
