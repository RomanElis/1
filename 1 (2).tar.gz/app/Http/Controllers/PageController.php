<?php

namespace App\Http\Controllers;

use App\Models\Page;
use Illuminate\Http\Request;

class PageController extends Controller
{
    public function show($slug = false)
    {
        //
        $page = Page::whereSlug($slug)->where('activity', 1)->first();
        if(!$page) {
            abort(404, 'Страница не найдена!');
        }

        view()->share('site_title', $page->title);
        view()->share('meta', [
            'title'       => $page->description,
            'description' => $page->description,
            'keywords'    => $page->keyword
        ]);

        $template_name = view()->exists($page->template_name) ? $page->template_name : 'page';
        return view($template_name, compact('page'));
    }
}
