<?php

namespace App\Http\Controllers;

use App\Models\Deposit;
use App\Models\Paid;
use App\Models\SystemPayment\SystemPayment;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Config;

class DepositController extends Controller
{
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request, [
            'sum'     => 'required|numeric|numeric|min:' . Config::get('settings.addcash_min') ?? 1,
            'payment' => 'required'
        ]);

        $systemPaymentAvailable = (new SystemPayment)->getSystems()->whereActivity()->findById($request->post('payment'))->item();
        if(!$systemPaymentAvailable)
        {
            return back()->withErrors([__('front.systempayment_not_available')]);
        }


        $paramsPayment = explode('--', $request->post('payment'));
        $paramsPaymentMain = array_pop($paramsPayment);
        $paramsPaymentSub = array_pop($paramsPayment);

        $payment = new Paid;
        $createPay = $payment->depositPay([
            'sum'       => $request->post('sum'),
            'payment'   => $paramsPaymentMain,
            'subsystem' => $paramsPaymentSub
        ]);


        $jsonData = [
            'data' => [
                'type'    => $createPay['status'],
                'message' => $createPay['info']
            ],
            'pay_id' => $createPay['create_id'],
            'pay_slug' => $createPay['create_slug'],
            'pay'    => [
                'title'    => $createPay['pay']['title'],
                'name'     => $createPay['pay']['name'],
                'id'       => $createPay['pay']['id'],
                'email'    => $createPay['pay']['email'],
                'quantity' => $createPay['pay']['quantity'],
                'total'    => $createPay['pay']['total']
            ]
        ];

        if($request->ajax()){
            return response()->json($jsonData);
        }

        return redirect()->route('payment_show', $createPay['create_slug']);
    }

}
