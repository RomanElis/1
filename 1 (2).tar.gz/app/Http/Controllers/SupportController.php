<?php

namespace App\Http\Controllers;

use App\Mail\SupportShipped;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Mail;

class SupportController extends Controller
{
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request, [
            'email'    => 'required|email',
            'name'     => 'required',
            'theme'    => 'required',
            //'order_id' => 'numeric',
            'messages' => 'required'
        ], [], [
            'email'    => '«Email»',
            'name'     => '«Имя»',
            'theme'    => '«Тема»',
            //'order_id' => '«Номер заказа»',
            'messages' => '«Сообщение»',
        ]);


        $supportId = time();

        /*
         * Отправляем письмо на почту с заказом
         */
        Mail::to(Config::get('settings.support_email'))->send(new SupportShipped((object)[
            'subject'  => 'Техподдержка #' . $supportId,
            'id'       => $supportId,
            'email'    => $request->post('email'),
            'name'     => $request->post('name'),
            'theme'    => $request->post('theme'),
            'order_id' => $request->post('order_id'),
            'messages' => $request->post('messages')
        ]));

        return redirect()->route('front.pages.show', 'support')->with('success', __('front.support_sending'));
    }
}
