<?php


namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Config;


class SupportShipped extends \Illuminate\Mail\Mailable
{
    use Queueable, SerializesModels;

    /**
     * The order instance.
     *
     * @var Support
     */
    public $style;
    public $support;
    public $from;

    /**
     * Create a new message instance.
     */
    public function __construct($support)
    {
        $this->support = $support;
        $this->subject(Config::get('settings.support_email') . ' - ' .$this->support->subject);
        $this->from(Config::get('settings.feedback_email'), Config::get('settings.feedback_name'));

        $this->style['td_reset'] = 'padding: 10px; margin: 0; border: 1px solid #ccc; border-collapse: collapse; border-spacing: 0; background: 0;';
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        return $this->view('emails.support');
    }
}
