<?php


namespace App\Mail;

use App\Models\Purchase;
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Config;


class PurchaseShipped extends \Illuminate\Mail\Mailable
{
    use Queueable, SerializesModels;

    /**
     * The order instance.
     *
     * @var Purchase
     */
    public $purchase;
    public $from;

    /**
     * Create a new message instance.
     */
    public function __construct($purchase)
    {
        $this->purchase = $purchase;
        $this->subject(Config::get('settings.feedback_shop') . ' - ' .$this->purchase->subject);
        $this->from(Config::get('settings.feedback_email'), Config::get('settings.feedback_name'));
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        return $this->view('emails.purchase_checkout');
    }
}
