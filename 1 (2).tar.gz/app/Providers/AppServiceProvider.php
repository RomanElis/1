<?php

namespace App\Providers;

use App\Models\Paid;
use App\Models\Purchase;
use Illuminate\Support\Facades\Blade;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        //

    }

    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        //
        view()->share('site_url', url('/'));

        Blade::directive('currencyFormatHTML', function ($value) {
            $data = '';
            $data .= '<span class="sum--value">' . "<?php echo number_format($value, 2, '.', ' '); ?>" . '</span>';
            $data .= ' <span class="sum--currency"><span>руб.</span></span>';
            return $data;
        });


        Blade::directive('currencyFormatSTRING', function ($value) {
            return "<?php echo number_format($value, 2, '.', ' '); ?>";
        });

        view()->share('metas', base64_decode('PG1ldGEgbmFtZT0iZ2VuZXJhdG9yIiBjb250ZW50PSJlbGl0ZS1kZXNpZ25zLnJ1IiAvPg=='));

//        Blade::directive('captcha_string', function ($nameCap) {
//            if(isset($nameCap)) {
//                $total = rand(10,50);
//                $secret = rand(1,10);
//                $result[] = $total - $secret;
//                $result[] = $total;
//                $secret = substr(md5($secret), 0, 4);
//                //setcookie('captcha_' . $params['name'], $secret, time()+3600);
//
//                session(['captcha_' . $nameCap => $secret]);
//                $return = $result[0] . ' + ? = ' . $result[1];
//            } else {
//                $return = '';
//            }
//            return $return;
//        });

//        Blade::directive('getRouteModuleName', function ($expression) use($request) {
//            $path = false;
//
//            $currentPath = $request->path();
//            $values = explode("/", $currentPath);
//            if(count($values))
//            {
//                array_pop($values);
//                $path = $values[0];
//            }
//            return $path;
//        });

//        $path = false;
//        //$currentPath = $request->path();
//        $currentPath = app('request')->path();
//        $values = explode("/", $currentPath);
//        if(count($values))
//        {
//            array_pop($values);
//            $path = $values[1];
//        }
//        view()->share('getRouteModuleName', $path);
        //
    }
}
