<?php
return [
    'id'          => 'freekassa',
    'controller'  => 'Freekassa',
    'name'        => 'FreeKassa',
    'method'      => 'callback',
    'data'        => [
    ],
    'form'        => [
        [
            'label' => 'Merchant id',
            'type'  => 'text',
            'name'  => 'merchant_id'
        ],
        [
            'label' => 'Секретное слово',
            'type'  => 'text',
            'name'  => 'pass1'
        ],
        [
            'label' => 'Секретное слово 2',
            'type'  => 'text',
            'name'  => 'pass2'
        ]
    ],
    'callback' => [
        ['label' => 'GET: RESULT URL', 'value' => '%SITE_URL%/payment_callback/freekassa/result'],
        ['label' => 'GET: SUCCESS URL', 'value' => '%SITE_URL%/payment_callback/freekassa/success'],
        ['label' => 'GET: ERROR URL', 'value' => '%SITE_URL%/payment_callback/freekassa/error'],
    ],
    'description' => 'Введите вышеуказанные настройки оповещения сайта в платежной системе. А также доп.настройки:<br> Подтверждение платежа: Требуется<br> Кто платит комиссию: Магазин'
    //    'callbacks' => [
    //        ['label' => 'Success URL', 'value' => route('front.payment_system.callback', 'freekassa')]
    //    ]
];
