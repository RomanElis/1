<?php
namespace App\Models\SystemPayment\Freekassa;


use Illuminate\Support\Facades\Config;


class Freekassa
{
    var $payEntity;
    var $payData;

    /*
     * Данные от системы
     */
    var $paymentData = [
        'status' => false,
        'info'   => false,
        'url'    => false,
        'return' => false,
        'user_pay' => false
    ];


    public function setPay($payEntity, $payData)
    {
        $this->payEntity = $payEntity;
        $this->payData = $payData;
        return $this;
    }

    public function getPaymentData($get)
    {
        return isset($this->paymentData[$get]) && !empty($this->paymentData[$get]) ? $this->paymentData[$get] : false;
    }

    public function createData($callPaid = false)
    {
        $sign = md5($this->payEntity['data']['merchant_id'].':'.floatval($this->payData['total']).':'.$this->payEntity['data']['pass1'].':'.$this->payData['pay_id']);

        $data = array(
            'm'        => $this->payEntity['data']['merchant_id'],
            'oa'       => floatval($this->payData['total']),
            'o'        => $this->payData['pay_id'],
            //'Desc'           => $pay_desc,
            's'        => $sign,
            //, 'i'       => '63',
            'lang'     => "ru",
            'us_login' => $this->payData['pay_id']
            //, 'IsTest' => 1
        );

        $this->paymentData = [
            'status' => true,
            'info'   => 'Форма создана',
            'url'    => 'http://www.free-kassa.ru/merchant/cash.php?' . http_build_query($data),
            'return' => 'redirect'
        ];
        return $this;
    }



    /*
     * Функция проверки возможности для оплаты
     */
    public function existCost()
    {
        $this->paymentData['status'] = true;
        return $this;
    }




    /*
     * Параметры валидации
     */
    var $params = ['id' => null, 'sign' => null];

    /*
     * Проверка
     */
    public function checkError($text = 'Bad pay')
    {
        $returnData = [
            'status' => false,
            'error'  => [
                'text' => $text,
                'code' => 400
            ]
        ];
        return $returnData;
    }

    /*
     * Загрузка параметров системы
     */
    public function checkLoadParams($request)
    {
        $this->params['id'] = $request->input('MERCHANT_ORDER_ID');
        $this->params['sign'] = $request->input('SIGN');
        $this->params['total'] = $request->input('AMOUNT');
        $this->params['intid'] = $request->input('intid');
        $this->params['merchant_id'] = $request->input('MERCHANT_ID');
        return $this;
    }

    /*
     * Проверка сигнатуры
     */
    public function checkSignature($paidData)
    {
        $returnData = ['id' => $this->params['id'], 'status' => false, 'error' => false];


        /*
         * Комбинируем подпись
         */
        $sign = md5($this->payEntity['data']['merchant_id'].':'.$this->params['total'].':'.$this->payEntity['data']['pass2'].':'.$this->params['id']);


        /*
         * Проверка корректности подписи
         */
        if (!($sign == $this->params['sign']))
        {
            return $this->checkError("bad sign");
        }

        /*
         * Сверка суммы
         */
        if(!(sprintf("%.2lf", $paidData['pay']['total']) == sprintf("%.2lf", $this->params['total'])))
        {
            return $this->checkError("bad sum");
        }

        /*
         * OK
         */
        $returnData['status'] = 'YES';
        return $returnData;
    }


}
