<?php
return [
    'id'          => 'balance',
    'controller'  => 'Balance',
    'name'        => 'Личный баланс',
    'method'      => 'local',
    'data'        => [
    ],
    'form'        => [
        [
            'label' => 'Максимальная сумма оплаты',
            'type'  => 'number',
            'name'  => 'maxpay',
            'label_append'  => 'Руб.'
        ],
//        [
//            'label' => 'Соответствие 1 рубль =',
//            'type'  => 'number',
//            'name'  => 'rates',
//            'label_append'  => 'Руб.'
//        ]
    ],
    'description' => 'Система личного баланса'
];
