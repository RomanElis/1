<?php
namespace App\Models\SystemPayment\Balance;

use App\Models\User;
use Illuminate\Support\Facades\Config;

class Balance
{
    var $payEntity;
    var $payData;

    /*
     * Данные от системы
     */
    var $paymentData = [
        'status' => false,
        'info'   => false,
        'url'    => false,
        'return' => false,
        'user_pay' => false
    ];


    public function setPay($payEntity, $payData)
    {
        $this->payEntity = $payEntity;
        $this->payData = $payData;
        return $this;
    }

    public function getPaymentData($get)
    {
        return isset($this->paymentData[$get]) && !empty($this->paymentData[$get]) ? $this->paymentData[$get] : false;
    }

    public function createData($callPaid = false)
    {
        if(!$callPaid) return $this;

        /*
         * Загружаем данные пользователя
         */
        if(!$this->payData['user'])
        {
            $this->paymentData['info'] = 'Авторизируйтесь на сайте';
            return $this;
        }

        if(!empty($this->payEntity['data']['maxpay']) && $this->payData['total'] > $this->payEntity['data']['maxpay'])
        {
            $this->paymentData['info'] = 'Превышена максимальная сумма оплаты';
            return $this;
        }

        $payTotal = $this->payData['total'];
        //$payTotal = $this->payData['total'] * ($this->payEntity['data']['rates'] ? floatval($this->payEntity['data']['rates']) : 1);

        $balanceMinus = $this->payData['user']->changeBalance('minus', $payTotal, 'update');

        $this->paymentData['status'] = true;
        $this->paymentData['return'] = 'local';

        $this->paymentData['user_pay'] = $balanceMinus;


        // $this->paymentData['status'];


        return $this;
    }


    /*
     * Функция проверки возможности для оплаты
     */
    public function existCost()
    {
        /*
         * Загружаем данные пользователя
         */
        if(!$this->payData['user'])
        {
            $this->paymentData['info'] = 'Авторизируйтесь на сайте';
            return $this;
        }

        if(!empty($this->payEntity['data']['maxpay']) && $this->payData['total'] > $this->payEntity['data']['maxpay'])
        {
            $this->paymentData['info'] = 'Превышена максимальная сумма оплаты';
            return $this;
        }

        $payTotal = $this->payData['total'];
        //$payTotal = $this->payData['total'] * ($this->payEntity['data']['rates'] ? floatval($this->payEntity['data']['rates']) : 1);

        /*
         * Если есть изменения цены от платежной системы
         */
        //$this->payData['total'] = 1000;

        /*
         * Загружаем данные пользователя
         */
        $balanceMinus = $this->payData['user']->changeBalance('minus', $payTotal, 'exist');
        $this->paymentData['status'] = $balanceMinus['status'];
        $this->paymentData['info'] = $balanceMinus['info'];
        $this->paymentData['return'] = 'local';

        $this->paymentData['user_pay'] = $balanceMinus;

        //$this->wwww = $balanceMinus;


        return $this;
    }
}
