<?php

return [
    'id'          => 'enotpay',
    'controller'  => 'Enotpay',
    'name'        => 'EnotPay',
    'method'      => 'callback',
    'data'        => [
    ],
    'form'        => [
        [
            'label' => 'Merchant (Номер магазина)',
            'type'  => 'text',
            'name'  => 'merchant_id'
        ],
        [
            'label' => 'Секретное слово',
            'type'  => 'text',
            'name'  => 'pass1'
        ],
        [
            'label' => 'Секретное слово 2',
            'type'  => 'text',
            'name'  => 'pass2'
        ]
    ],
    'callback' => [
        ['label' => 'GET: RESULT URL', 'value' => '%SITE_URL%/payment_callback/enotpay/result'],
        ['label' => 'GET: SUCCESS URL', 'value' => '%SITE_URL%/payment_callback/enotpay/success'],
        ['label' => 'GET: ERROR URL', 'value' => '%SITE_URL%/payment_callback/enotpay/error'],
    ],
    'description' => 'Введите вышеуказанные настройки оповещения сайта в платежной системе.'
];
