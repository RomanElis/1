<?php

namespace App\Models\SystemPayment;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Config;

class SystemPayment extends Model
{
    use HasFactory;

    var $loadCreator;

    /*
     * Конфиг систем
     */
    var $item = false;
    var $items = [
        'balance'   => [],
        'freekassa' => [],
        'enotpay'   => []
    ];

    /*
     * Данные для платежной системы
     */
    var $createData = [
        'user_id'       => 0,
        'user'       => false,
        'pay_id'       => 0,
        'product_id'   => 0,
        'total'        => 0,
        'redirect_url' => false,
    ];

    /*
     * Данные от системы
     */
    var $paymentData = [
        'status' => false,
        'info'   => false,
        'url'    => false,
        'return' => false,
        'user_pay' => false
    ];

    public function getPaymentData($get)
    {
        return isset($this->paymentData[$get]) && !empty($this->paymentData[$get]) ? $this->paymentData[$get] : false;
    }


    public function setOption($var, $val)
    {
        //$this->{$var} = $val;
        $this->{$var} = array_merge($this->{$var}, $val);
        return $this;
    }


    public function getOption($var)
    {
        return $this->{$var};
    }

    // Получаем все системы
    public function getSystems()
    {
        foreach ($this->items as $itemName => $itemOptions) {
            $path = __DIR__ . '/' . ucfirst($itemName) . '/init.php';
            //$pathModel = __DIR__ . '/' . $itemName . '/model.php';
            if(file_exists($path))
            {
                $includeData = include($path);
                if(!isset($includeData['name'])) {
                    unset($this->items[$itemName]);
                    continue;
                }
                $this->items[$itemName] = $includeData;
                //$this->items[$itemName]['create'] = include($pathModel);
                continue;
            }
            unset($this->items[$itemName]);
        }
        return $this;
    }


    public function whereParam($methodName, $methodValue)
    {
        $filtered = collect($this->items)->reject(function ($value, $key) use($methodName, $methodValue) {
            $methodValue = is_string($methodValue) ? [$methodValue] : $methodValue;
            return isset($value[$methodName]) && in_array($value[$methodName], $methodValue) ? false : true;
        });

        $this->items = $filtered->all();
        return $this;
    }



    // Подгружаем конфиг платежной системы и фильтруем активные/включенные системы
    public function whereActivity()
    {
        $getOptions = Config::get('system.payment');

        foreach ($this->items as $itemName => $itemOptions) {
            if(!(isset($getOptions[$itemName]['activity']) && $getOptions[$itemName]['activity'] == 'enable'))
            {
                unset($this->items[$itemName]);
                continue;
            }
            $this->items[$itemName]['data'] = array_merge($this->items[$itemName]['data'], $getOptions[$itemName]);
        }
        return $this;
    }

    /*
     * Получаем систему по ID
     */
    public function findById($id = false)
    {
        $this->items = [$id => isset($this->items[$id]) ? $this->items[$id] : false];
        $this->item = current($this->items);
        return $this;
    }


    public function loadCreator()
    {
        $modelName = $this->item();
        $nameSystem = '\App\Models\SystemPayment\\' . $modelName['controller'] . '\\' . $modelName['controller'];
        $this->loadCreator = new $nameSystem();
        $this->loadCreator->setPay($this->item, $this->createData);

        return $this;
    }


    // Получаем список систем
    public function items()
    {
        return $this->items;
    }


    public function hasExist()
    {
        return $this->item;
    }


    public function item()
    {
        return array_shift($this->items);
    }

}
