<?php

namespace App\Models;

use App\Mail\PurchaseShipped;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Mail;

class Purchase extends Model
{
    use HasFactory;


    protected $fillable = [
        'user_id',
        'user_email',
        'product_id',
        'product_title',
        'quantity',
        'payment_total',
        'payment_method',
        'payment_info',
        'paid',
        'goods',
        'comment',
        'payment_at',
    ];

    protected $dates = [
        'payment_at',
    ];


    public function scopeExclude($query, $value = [])
    {
        return $query->select(array_diff($this->fillable, (array) $value));
    }

    /**
     * Получить пользовательские данные
     */
    public function user()
    {
        return $this->belongsTo('App\Models\User', 'user_id');
    }
    public function product()
    {
        return $this->belongsTo('App\Models\Product');
    }

    /**
     * Получить основу заказа
     */
    public function paid_data()
    {
        return $this->hasOne('App\Models\Paid', 'attach_id');
    }

    /**
     * Получить чек
     */
//    public function paids()
//    {
//        return $this->belongsTo('App\Models\Paid', 'paid_id');
//    }

    public function cruds()
    {
        return [
            'options'   => [],
            'sorttable' => true,
            'items'     => [
                [
                    'label'    => '',
                    'id'       => 'item_check',
                    'cols'     => false,
                    'template' => 'item_check',
                    'header'   => 'item_check',
                ],
                [
                    'label'    => 'ID',
                    'id'       => 'id',
                    'cols'     => false,
                    'template' => 'text',
                    'header'   => 'order',
                ],
                [
                    'label'            => 'Товар',
                    'id'               => 'product_id',
                    'cols'             => false,
                    'template'         => 'product_static',
                    'header'           => false,
                ],
                [
                    'label'            => 'Кол-во',
                    'id'               => 'quantity',
                    'cols'             => false,
                    'template'         => 'text',
                    'header'           => 'order',
                ],
                [
                    'label'            => 'Сумма',
                    'id'               => 'payment_total',
                    'cols'             => false,
                    'template'         => 'text_link',
                    'href_route_name'  => 'dash.purchases.edit',
                    'href_route_value' => 'id',
                    'value_currency'   => 'formatSTRING',
                    'header'           => 'order',
                ],
                [
                    'label'    => 'Клиент',
                    'id'       => 'user_id',
                    'cols'             => false,
                    'template' => 'user',
                    'header'   => false,
                ],
                [
                    'label'    => 'Email',
                    'id'       => 'user_email',
                    'cols'     => false,
                    'template' => 'text',
                    'header'   => false,
                ],
                [
                    'label'    => 'Метод оплаты',
                    'id'       => 'payment_method',
                    'cols'     => false,
                    'template' => 'text',
                    'header'   => 'order',
                ],
                [
                    'label'    => 'ID платежа',
                    'id'       => 'paid_data',
                    'cols'     => false,
                    'template' => 'paid_data',
                    'header'   => false,
                ],
                [
                    'label'    => 'Система',
                    'id'       => 'payment_info',
                    'cols'     => false,
                    'template' => 'text_detail',
                    'header'   => false,
                ],
                [
                    'label'    => 'Статус',
                    'id'       => 'paid',
                    'cols'     => false,
                    'template' => 'paid',
                    'header'   => 'order',
                ],
                [
                    'label'    => 'Дата оплаты',
                    'id'       => 'payment_at',
                    'cols'     => false,
                    'template' => 'date',
                    'header'   => 'order',
                ],
                'created_at' => [
                    'label'    => 'Дата создания',
                    'id'       => 'created_at',
                    'cols'     => false,
                    'template' => 'date',
                    'header'   => 'order',
                ],
                'control'    => [
                    'label'    => '',
                    'id'       => '',
                    'cols'     => false,
                    'template' => 'control',
                    'buttons'  => [
                        [
                            'label'               => 'Скачать',
                            'href_route_name'     => 'payment_download',
                            'href_route_value'    => 'paid_data',
                            'href_route_subvalue' => 'slug',
                            'class'               => 'btn btn-success',
                            'icon'                => 'oi oi-data-transfer-download',
                            'attrs'               => [
                                'target' => '_blank'
                            ]
                        ],
                        [
                            'label'               => 'Посмотреть',
                            'href_route_name'     => 'payment_show',
                            'href_route_value'    => 'paid_data',
                            'href_route_subvalue' => 'slug',
                            'class'               => 'btn btn-info',
                            'icon'                => 'oi oi-eye',
                            'attrs'               => [
                                'target' => '_blank'
                            ]
                        ],
                        [
                            'label'            => 'Изменить',
                            'href_route_name'  => 'dash.purchases.edit',
                            'href_route_value' => 'id',
                            'class'            => 'btn btn-secondary',
                            'icon'             => 'oi oi-pencil',
                            'attrs'            => []
                        ],
                        [
                            'label' => 'Удалить',
                            'href'  => '#',
                            'class' => 'btn btn-danger',
                            'icon'  => 'oi oi-x',
                            'attrs' => [
                                'data-crud-btn-remove-id' => '__ID__'
                            ]
                        ]
                    ],
                    'header'   => false,
                ],
            ]
        ];
    }



    public function getFilterLinks()
    {
        $modelTabs = DB::table('purchases')
            ->select(DB::raw('purchases.paid as paid_name, count(purchases.paid) as paid_count'))
            ->groupBy('purchases.paid')
            ->get();

        if(!$modelTabs) return false;

        $tabsItems = [];
        foreach ($modelTabs as $tabData) {
            $tabsItems[$tabData->paid_name] = $tabData->paid_count;
        }
        $tabsItems['all'] = array_sum($tabsItems);

        return $tabsItems;
    }



    public function goodsFileToSave($filePath)
    {
        $extract = $this->goodsFileExtract($filePath);
        $inject = $this->goodsInject($extract);
        return (object)[
            'goods' => $inject,
            'stock' => count($extract)
        ];
    }

    public function goodsFileExtract($filePath = false)
    {
        if(!file_exists($filePath)) return [];
        $array = file($filePath, FILE_IGNORE_NEW_LINES);
        $array = array_diff($array, [""]);
        if(!count($array)) return [];
        return $array;
    }

    public function goodsInject($array = [])
    {
        if(!count($array)) return '';
        $string = implode(PHP_EOL, $array);
        return $string;
    }


    public function downloadFileTxt($data, $fileName = 'goods')
    {
        return response()->streamDownload(function () use($data) {
            echo $data;
        }, $fileName . '.txt');
    }


    /**
     * Извлекает из товара ключи и сохраняет остаток
     */
    public function goodsExtractByModel($quantity = 1)
    {
        $data = [
            'status' => false,
            'error' => '',

            'inject'       => [],
            'inject_count' => 0,

            'extract'       => [],
            'extract_count' => 0
        ];

        /**
         * Выводим ошибку, если поле ключей пустое у товара
         */
        if(!$this->goods)
        {
            $data['error'] = 'empty';
            return $data;
        }

        $goodsExtract = explode(PHP_EOL, $this->goods);
        $goodsExtract = array_diff($goodsExtract, [""]);

        /**
         * Выводим ошибку, если количество выдачи больше доступного на складе
         */
        if(count($goodsExtract) < (int)$quantity)
        {
            $data['error'] = 'quantity';
            return $data;
        }

        /**
         * Извлекаем
         */
        $goodsInject = array_splice($goodsExtract, (int)$quantity, count($goodsExtract));
        $data['inject_count'] = count($goodsInject);


        /**
         * Сохраняем остаток в БД и возвращаем запрос
         */
        if ($this->update([
            'goods' => $this->goodsInject($goodsInject),
            //'stock' => $data['inject_count']
        ]))
        {
            $data['inject'] = $goodsInject;
            $data['extract'] = $goodsExtract;
            $data['extract_count'] = count($goodsExtract);
            $data['status'] = true;
            $data['error'] = 'success';
        }
        else
        {
            $data['error'] = 'error update';
        }

        return $data;
    }




    /*
     * Исполняем заказ
     */
    public function _extractPaidSuccess($core)
    {
        /*
         * Загружаем товар
         */
        $product = Product::find($core->paidOptions->product_id);
        if(!$product)
        {
            // Err
            $core->paidData['info'] = 'Товар не найден';
            return $core;
        }


        /*
         * Проверяем количество товара
         */
//        if(!$product->hasGoodsQuantity($core->paidOptions['quantity']))
//        {
//            // Err
//            $core->paidData['status'] = 0;
//            $core->paidData['info'] = __('messages.product_buy_denied_quantity');
//            return $core;
//        }

        /*
         * Добавляем товар пользователю
         */
        $goods = $product->goodsExtractByModel($core->paidOptions['quantity']);
        if(!$goods['status'])
        {
            // Err
            $core->paidData['status'] = 0;
            $core->paidData['info'] = __('messages.product_buy_denied_quantity');
            return $core;
        }

        $core->paidOptions->goods = $product->goodsInject($goods['extract']);


        /*
         * Отправляем письмо на почту с заказом
         */
        Mail::to($core->paidData['pay']['email'])->send(new PurchaseShipped((object)[
            'subject' => 'Заказ #' . $core->paidData['pay']['pay_id'],
            'order_email'    => $core->paidData['pay']['email'],
            'order_id'       => $core->paidData['pay']['pay_id'],
            'order_url'      => route('payment_show', $core->paidData['create_slug']),
            'order_file_url' => route('payment_download', $core->paidData['create_slug'])
        ]));


        return $core;
    }
}
