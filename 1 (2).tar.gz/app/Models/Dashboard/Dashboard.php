<?php

namespace App\Models\Dashboard;

use App\Models\Purchase;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class Dashboard extends Model
{
    use HasFactory;


    static function getStatsRange($from = false, $to = false, $filter = [])
    {
        $dateFrom = date('Y-m-d H:i:s', strtotime('-7 day'));
        $dateTo = date('Y-m-d H:i:s');

        if($from)
        {
            $dateFrom = \DateTime::createFromFormat("d.m.Y", $from, new \DateTimeZone('Europe/Moscow'))->format('Y-m-d');
        }
        if($to)
        {
            $dateTo = \DateTime::createFromFormat("d.m.Y", $to, new \DateTimeZone('Europe/Moscow'))->modify('+1 day')->format('Y-m-d');
        }

        $cashboxHelper = Purchase::whereBetween(DB::raw('DATE(created_at)'), [$dateFrom, $dateTo])->where('paid', '=', '1');

        if($filter && in_array('real_money', $filter))
        {
            $cashboxHelper->where('real_money', 1);
        }

        $cashboxHelper->select(DB::raw("
            DATE_FORMAT(purchases.created_at, '%Y-%m-%d') as date_format,
            COUNT(purchases.created_at) as total_items,
            SUM(purchases.payment_total) as total_cost
        "));

        $cashboxHelper->groupBy('date_format');

        $cashboxHelper = $cashboxHelper->get();

        $cashboxItems = [];
        foreach ($cashboxHelper as $statDay => $statDate)
        {
            $cashboxItems[$statDate['date_format']] = [
                'date' => $statDate['date_format'],
                'total_cost' => $statDate['total_cost'],
                'total_items' => $statDate['total_items']
            ];
        }
        unset($cashboxHelper);


        $statsRange = new \DatePeriod(
            new \DateTime($dateFrom),
            new \DateInterval('P1D'),
            new \DateTime($dateTo)
        );
        foreach ($statsRange as $statDay => $data)
        {
            $statDate = $data->format('Y-m-d');
            if(!array_key_exists($statDate, $cashboxItems))
            {
                $cashboxItems[$statDate] = [
                    'date' => $statDate,
                    'total_cost' => 0,
                    'total_items' => 0
                ];
            }
        }
        ksort($cashboxItems);

        return $cashboxItems;
    }
}
