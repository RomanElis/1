<?php

namespace App\Models\Dashboard;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SettingDash extends Model
{
    use HasFactory;

    public static $settingsName = 'settings';

    public static function setOptionsByFile($options, $configFileName)
    {
        self::$settingsName = $configFileName;
        return self::setOptions($options);
    }

    public static function setOptions($options = [])
    {
        $ss = self::getOptions();
        $ss = array_merge($ss, $options);
        file_put_contents(base_path() . '/config/' . self::$settingsName . '.php', '<?php' . PHP_EOL . ' return ' . var_export($ss, true) . ';');
    }

    public static function getOptions()
    {
        return include(base_path() . '/config/' . self::$settingsName . '.php');
    }

    public static function getOptionsFile()
    {
        $gets = file_get_contents(base_path() . '/config/' . self::$settingsName . '.php');
        return $gets;
    }
}
