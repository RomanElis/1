<?php

namespace App\Models\Dashboard;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ExportToFile extends Model
{
    use HasFactory;

    var $header = [];
    var $items = [];
    var $fileName = [];

    public function loadModel($name)
    {
        $loadModel = 'App\\Models\\' . $name;
        $items = $loadModel::all();

        $header = array_merge(['id'], $items[0]->getFillable());

        $this->items = $items;
        $this->header = $header;
        $this->fileName = 'Export table ' . $name . ' of ' . date('Y-m-d--H-i-s');

        return $this;
    }

    public function setOptions($options = [])
    {
        $this->items = $options['items'];
        $this->header = $options['header'];
        $this->fileName = $options['fileName'];
        return $this;
    }

    public function exportCsv() {

        $items = $this->items;
        $fileName = $this->fileName . '.csv';
        $columns = $this->header;

        $headers = array(
            "Content-type"        => "text/csv",
            "Content-Disposition" => "attachment; filename=$fileName",
            "Pragma"              => "no-cache",
            "Cache-Control"       => "must-revalidate, post-check=0, pre-check=0",
            "Expires"             => "0"
        );

        $callback = function() use($items, $columns) {
            $file = fopen('php://output', 'w');
            fprintf($file, chr(0xEF).chr(0xBB).chr(0xBF));
            fputcsv($file, $columns, ";");

            $row = [];
            foreach ($items as $task) {
                foreach ($columns as $colName => $col)
                {
                    if(is_array($task->$col))
                    {
                        $task->$col = json_encode($task->$col, JSON_UNESCAPED_UNICODE);
                    }
                    $row[$col] = $task->$col;
                }

                fputcsv($file, $row, ";");
            }

            fclose($file);
        };

        return response()->stream($callback, 200, $headers);
    }
}
