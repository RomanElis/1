<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;

class Page extends Model
{
    use HasFactory;

    protected $fillable = [
        'slug',
        'title',
        'title_h1',
        'meta_title',
        'meta_description',
        'meta_keywords',
        'description',
        'parent_id',
        'position',
        'activity',
        'template_name',
        'lang_id'
    ];

//    public function setTitleAttribute($value)
//    {
//        $this->attributes['title'] = $value;
//        if(!$this->attributes['slug'])
//        {
//            $this->attributes['slug'] = Str::slug($value, '-');
//        }
//    }

    public function cruds()
    {
        return [
            'options'   => [],
            'sorttable' => true,
            'items'     => [
                [
                    'label'    => '',
                    'id'       => 'item_check',
                    'cols'     => false,
                    'template' => 'item_check',
                    'header'   => 'item_check',
                ],
                'id'         => [
                    'label'    => 'ID',
                    'id'       => 'id',
                    'cols'     => false,
                    'template' => 'text',
                    'header'   => 'order',
                ],
                'title'      => [
                    'label'            => 'Заголовок',
                    'id'               => 'title',
                    'cols'             => 'width',
                    'template'         => 'text_link',
                    'href_route_name'  => 'dash.pages.edit',
                    'href_route_value' => 'id',
                    'header'           => 'order',
                ],
                'slug'       => [
                    'label'    => 'Ссылка',
                    'id'       => 'slug',
                    'cols'     => false,
                    'template' => 'text_link',
                    'href_route_name'  => 'front.pages.show',
                    'href_route_value' => 'slug',
                    'header'   => 'order',
                ],
                'activity'   => [
                    'label'    => 'Статус',
                    'id'       => 'activity',
                    'cols'     => false,
                    'template' => 'inputActivity',
                    'header'   => 'order',
                ],
                'updated_at' => [
                    'label'    => 'Дата изменения',
                    'id'       => 'updated_at',
                    'cols'     => false,
                    'template' => 'date',
                    'header'   => 'order',
                ],
                'created_at' => [
                    'label'    => 'Дата создания',
                    'id'       => 'created_at',
                    'cols'     => false,
                    'template' => 'date',
                    'header'   => 'order',
                ],
                'control'    => [
                    'label'    => '',
                    'id'       => '',
                    'cols'     => false,
                    'template' => 'control',
                    'buttons'  => [
                        [
                            'label'            => 'Посмотреть',
                            'href_route_name'  => 'front.pages.show',
                            'href_route_value' => 'slug',
                            'class'            => 'btn btn-info',
                            'icon'             => 'oi oi-eye',
                            'attrs'            => [
                                'target' => '_blank'
                            ]
                        ],
                        [
                            'label'            => 'Изменить',
                            'href_route_name'  => 'dash.pages.edit',
                            'href_route_value' => 'id',
                            'class'            => 'btn btn-secondary',
                            'icon'             => 'oi oi-pencil',
                            'attrs'            => []
                        ],
                        [
                            'label' => 'Удалить',
                            'href'  => '#',
                            'class' => 'btn btn-danger',
                            'icon'  => 'oi oi-x',
                            'attrs' => [
                                'data-crud-btn-remove-id' => '__ID__'
                            ]
                        ]
                    ],
                    'header'   => false,
                ],
            ]
        ];
    }

}
