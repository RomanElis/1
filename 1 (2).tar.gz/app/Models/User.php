<?php

namespace App\Models;

use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Illuminate\Support\Facades\DB;

class User extends Authenticatable
{
    use HasFactory, Notifiable;

    protected $dates = [
        'created_at',
        'updated_at',
        'last_login'
    ];

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name',
        'email',
        'password',
        'group',
        'balance',
        'telegram',
        'last_login',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password',
        'remember_token',
        'last_login',
        'last_payment',
        'last_purchase',
    ];

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
//        'created_at' => 'datetime',
//        'updated_at' => 'datetime',
    ];

    /**
     * Получить заказы пользователя
     */
    public function purchase()
    {
        return $this->hasOne('App\Models\Purchase', 'user_id');
    }

    /**
     * Получить пополнения пользователя
     */
    public function deposit()
    {
        return $this->hasOne('App\Models\Deposit', 'user_id');
    }


    public function isGroup()
    {
        return $this->group;
    }

    public function getGroupItems()
    {
        $group_items = [
            'user'  => [
                'id'    => 'user',
                'label' => 'Пользователь'
            ],
            'admin' => [
                'id'    => 'admin',
                'label' => 'Администратор'
            ],
            'ban'   => [
                'id'    => 'ban',
                'label' => 'Заблокирован'
            ]
        ];
        return $group_items;
    }


    public function cruds()
    {
        return [
            'options'   => [],
            'sorttable' => false,
            'items'     => [
                [
                    'id'       => 'item_check',
                    'cols'     => false,
                    'template' => 'item_check',
                    'header'   => 'item_check',
                ],
                [
                    'label'    => 'ID',
                    'id'       => 'id',
                    'cols'     => false,
                    'template' => 'text',
                    'header'   => 'order',
                ],
                [
                    'label'            => 'Имя',
                    'id'               => 'name',
                    'cols'             => false,
                    'template'         => 'text_link',
                    'href_route_name'  => 'dash.users.edit',
                    'href_route_value' => 'id',
                    'header'           => 'order',
                ],
                [
                    'label'            => 'Email',
                    'id'               => 'email',
                    'cols'             => false,
                    'template'         => 'email_link',
                    'header'           => 'order',
                ],
                [
                    'label'    => 'Баланс',
                    'id'       => 'balance',
                    'cols'     => false,
                    'template' => 'currencyFormatHTML',
                    'header'   => 'order',
                ],
                [
                    'label'    => 'Группа',
                    'id'       => 'group',
                    'cols'     => false,
                    'template' => 'text',
                    'header'   => 'order',
                ],
                [
                    'label'           => 'Заказов',
                    'id'              => 'purchase_count',
                    'cols'            => false,
                    'template'        => 'find_link',
                    'href_route_name' => 'dash.purchases.index',
                    'href_find_name'  => '?where=user_id&search=__ID__',
                    'header'          => 'order',
                ],
                [
                    'label'    => 'Дата изменения',
                    'id'       => 'updated_at',
                    'cols'     => false,
                    'template' => 'date',
                    'header'   => 'order',
                ],
                [
                    'label'    => 'Дата создания',
                    'id'       => 'created_at',
                    'cols'     => false,
                    'template' => 'date',
                    'header'   => 'order',
                ],
                [
                    'label'    => '',
                    'id'       => '',
                    'cols'     => false,
                    'template' => 'control',
                    'buttons'  => [
                        [
                            'label'            => 'Изменить',
                            'href_route_name'  => 'dash.users.edit',
                            'href_route_value' => 'id',
                            'class'            => 'btn btn-secondary',
                            'icon'             => 'oi oi-pencil',
                            'attrs'            => []
                        ],
                        [
                            'label' => 'Удалить',
                            'href'  => '#',
                            'class' => 'btn btn-danger',
                            'icon'  => 'oi oi-x',
                            'attrs' => [
                                'data-crud-btn-remove-id' => '__ID__'
                            ]
                        ]
                    ],
                    'header'   => false,
                ],
            ]
        ];
    }


    public function getFilterLinks()
    {
        $modelTabs = DB::table('users')
            ->select(DB::raw('users.group as group_name, count(users.group) as group_count'))
            ->groupBy('users.group')
            ->get();

        if(!$modelTabs) return false;

        $tabsItems = [];
        foreach ($modelTabs as $tabData) {
            $tabsItems[$tabData->group_name] = $tabData->group_count;
        }
        $tabsItems['all'] = array_sum($tabsItems);

        return $tabsItems;
    }


//    public function changeBalance($type = 'minus', $sum = 0, $take = false)
//    {
//        $datas = new \stdClass();
//        $datas->status = false;
//        $datas->error = '';
//        $datas->value_old = (double)$this->balance;
//        $datas->value_update = 0;
//        $datas->fund_need = 0;
//
//        if($type == 'plus')
//        {
//            $datas->value_update = (double)$this->balance + $sum;
//        }
//        elseif($type == 'minus')
//        {
//            $datas->value_update = (double)$this->balance - $sum;
//            $datas->fund_need = $datas->value_update < 0 ? (double)str_replace('-', '', $datas->value_update) : 0;
//            if($datas->value_old < $datas->value_update || $datas->value_update < 0)
//            {
//                $datas->error = 'Not enough funds';
//                return $datas;
//            }
//        }
//
//        if ($this->update(['balance' => $datas->value_update])) {
//            $datas->status = true;
//        }
//
//        return $datas;
//    }


    // Изменение баланса
    public function changeBalance($type = 'minus', $sum = 0, $take = 'update')
    {
        $data = [
            'status'       => false,
            'info'         => '',
            'value_old'    => (double)$this->balance,
            'value_update' => 0,
            'total'        => $sum,
            'fund_need'    => 0
        ];

        if($type == 'plus')
        {
            $data['value_update'] = (double)$this->balance + $sum;
            $data['info'] = __('front.balance.deposit_successful');
        }
        elseif($type == 'minus')
        {
            $data['value_update'] = (double)$this->balance - $sum;
            $data['fund_need'] = $data['value_update'] < 0 ? (double)str_replace('-', '', $data['value_update']) : 0;
            if($data['value_old'] < $data['value_update'] || $data['value_update'] < 0)
            {
                $data['info'] = __('front.balance.not_enough_funds');
                return $data;
            }
            $data['info'] = __('front.balance.withdrawal_successful');
        }

        if ($take == 'update' && $this->update(['balance' => $data['value_update']])) {
            $data['status'] = true;
        }
        elseif ($take == 'exist')
        {
            $data['status'] = true;
        }

        return $data;
    }


    public function getFavoritesCount()
    {
        return $this->favorites ? count(explode(',', $this->favorites)) : 0;
    }
}
