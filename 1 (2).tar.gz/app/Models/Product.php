<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    use HasFactory;

    protected $fillable = [
        'title',
        'type',
        'image',
        'description',
        'price',
        'goods',
        'stock',
        'position',
        'activity',
        'sales',
        'last_sale'
    ];

    protected $hidden = array('goods');



    public function getTypeItems()
    {
        $group_items = [
            'googs'  => [
                'id'    => 'googs',
                'label' => 'Товар'
            ],
            'header' => [
                'id'    => 'header',
                'label' => 'Заголовок'
            ],
            'split'  => [
                'id'    => 'subheader',
                'label' => 'Заголовок - разделитель'
            ]
        ];
        return $group_items;
    }

    public function cruds()
    {
        return [
            'options'   => [],
            'sorttable' => true,
            'items'     => [
                'sorttable' => [
                    'label'    => '',
                    'id'       => 'sorttable',
                    'cols'     => false,
                    'template' => 'sorttable',
                    'header'   => false,
                ],
                [
                    'label'    => '',
                    'id'       => 'item_check',
                    'cols'     => false,
                    'template' => 'item_check',
                    'header'   => 'item_check',
                ],
                'id'         => [
                    'label'    => 'ID',
                    'id'       => 'id',
                    'cols'     => false,
                    'template' => 'text',
                    'header'   => 'order',
                ],
                'image_url'      => [
                    'label'            => '',
                    'id'               => 'image',
                    'cols'             => 'imagebox',
                    'template'         => 'image_url',
                    'header'           => false,
                ],
                'title'      => [
                    'label'            => 'Заголовок',
                    'id'               => 'title',
                    'cols'             => 'width',
                    'template'         => 'text_link',
                    'href_route_name'  => 'dash.products.edit',
                    'href_route_value' => 'id',
                    'header'           => 'order',
                ],
                [
                    'label'    => 'Цена',
                    'id'       => 'price',
                    'cols'     => false,
                    'template' => 'inputPrice',
                    'header'   => 'order',
                ],
                'activity'   => [
                    'label'    => 'Статус',
                    'id'       => 'activity',
                    'cols'     => false,
                    'template' => 'inputActivity',
                    'header'   => 'order',
                ],
                'position'   => [
                    'label'    => 'Позиция',
                    'id'       => 'position',
                    'cols'     => false,
                    'template' => 'text',
                    'header'   => 'order',
                ],
                'stock'   => [
                    'label'    => 'Кол-во',
                    'id'       => 'stock',
                    'cols'     => false,
                    'template' => 'text',
                    'header'   => 'order',
                ],
                'updated_at' => [
                    'label'    => 'Дата изменения',
                    'id'       => 'updated_at',
                    'cols'     => false,
                    'template' => 'date',
                    'header'   => 'order',
                ],
                'created_at' => [
                    'label'    => 'Дата создания',
                    'id'       => 'created_at',
                    'cols'     => false,
                    'template' => 'date',
                    'header'   => 'order',
                ],
                'goods' => [
                    'label'    => 'Товар',
                    'id'       => false,
                    'cols'     => false,
                    'template' => 'goods',
                    'header'   => 'order',
                ],
                'products_adds' => [
                    'label'    => '',
                    'id'       => false,
                    'cols'     => false,
                    'template' => 'product_adds',
                    'header'   => false,
                ],
                'control'    => [
                    'label'    => '',
                    'id'       => '',
                    'cols'     => false,
                    'template' => 'control',
                    'buttons'  => [
//                        [
//                            'show_type'        => ['googs'],
//                            'label'            => 'Скачать',
//                            'href_route_name'  => 'dash.products.goods.download',
//                            'href_route_value' => 'id',
//                            'class'            => 'btn btn-success',
//                            'icon'             => 'oi oi-data-transfer-download',
//                            'attrs'            => []
//                        ],
//                        [
//                            'show_type'        => ['googs'],
//                            'label'            => 'Загрузить',
//                            'href_route_name'  => 'dash.products.edit',
//                            'href_route_value' => 'id',
//                            'class'            => 'btn btn-info',
//                            'icon'             => 'oi oi-data-transfer-upload',
//                            'attrs'            => []
//                        ],
                        [
                            'label'            => 'Изменить',
                            'href_route_name'  => 'dash.products.edit',
                            'href_route_value' => 'id',
                            'class'            => 'btn btn-secondary',
                            'icon'             => 'oi oi-pencil',
                            'attrs'            => []
                        ],
                        [
                            'label' => 'Удалить',
                            'href'  => '#',
                            'class' => 'btn btn-danger',
                            'icon'  => 'oi oi-x',
                            'attrs' => [
                                'data-crud-btn-remove-id' => '__ID__'
                            ]
                        ]
                    ],
                    'header'   => false,
                ],
            ]
        ];
    }


//    public function fileDataToSave($string)
//    {
//        return $this->fileDataToArray($string)->arrayDataToString()->goodsData;
//    }
//    public function fileDataToArray($string)
//    {
//        $lines = file($string, FILE_IGNORE_NEW_LINES);
//        $lines = array_diff($lines, [""]);
//        $this->goodsData['array'] = $lines;
//        return $this;
//    }
//    public function arrayDataToString($array = false)
//    {
//        if(!$array) $array = $this->goodsData['array'];
//        $lines = implode(PHP_EOL, $array);
//        $this->goodsData['string'] = $lines;
//        return $this;
//    }



    public function goodsFileToSave($filePath)
    {
        $extract = $this->goodsFileExtract($filePath);
        $inject = $this->goodsInject($extract);
        return (object)[
            'goods' => $inject,
            'stock' => count($extract)
        ];
    }

    public function goodsFileExtract($filePath = false)
    {
        if(!file_exists($filePath)) return [];
        $array = file($filePath, FILE_IGNORE_NEW_LINES);
        $array = array_diff($array, [""]);
        if(!count($array)) return [];
        return $array;
    }

    public function goodsInject($array = [])
    {
        if(!count($array)) return '';
        $string = implode(PHP_EOL, $array);
        return $string;
    }


    public function downloadFileTxt($data, $fileName = 'goods')
    {
        return response()->streamDownload(function () use($data) {
            echo $data;
        }, $fileName . '.txt');
    }


    /**
     * Извлекает из товара ключи и сохраняет остаток
     */
    public function goodsExtractByModel($quantity = 1)
    {
        $data = [
            'status' => false,
            'error' => '',

            'inject'       => [],
            'inject_count' => 0,

            'extract'       => [],
            'extract_count' => 0
        ];

        /**
         * Выводим ошибку, если поле ключей пустое у товара
         */
        if(!$this->goods)
        {
            $data['error'] = 'empty';
            return $data;
        }

        $goodsExtract = explode(PHP_EOL, $this->goods);
        $goodsExtract = array_diff($goodsExtract, [""]);

        /**
         * Выводим ошибку, если количество выдачи больше доступного на складе
         */
        if(count($goodsExtract) < (int)$quantity)
        {
            $data['error'] = 'quantity';
            return $data;
        }

        /**
         * Извлекаем
         */
        $goodsInject = array_splice($goodsExtract, (int)$quantity, count($goodsExtract));
        $data['inject_count'] = count($goodsInject);


        /**
         * Сохраняем остаток в БД и возвращаем запрос
         */
        if ($this->update([
            'goods' => $this->goodsInject($goodsInject),
            'stock' => $data['inject_count']
        ]))
        {
            $data['inject'] = $goodsInject;
            $data['extract'] = $goodsExtract;
            $data['extract_count'] = count($goodsExtract);
            $data['status'] = true;
            $data['error'] = 'success';
        }
        else
        {
            $data['error'] = 'error update';
        }

        return $data;
    }

    public function goodsExtractById($id = false)
    {

    }


    public function hasGoodsQuantity($quantity)
    {
        $stock = (int)$this->stock;
        if($stock > $quantity)
        {
            return $stock;
        }
        return false;
    }

}
