<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class Deposit extends Model
{
    use HasFactory;


    protected $fillable = [
        'user_id',
        'payment_total',
        'payment_method',
        'payment_info',
        'paid',
        'comment',
        'payment_at',
    ];

    protected $dates = [
        'payment_at',
    ];



    /**
     * Получить пользовательские данные
     */
    public function user()
    {
        return $this->belongsTo('App\Models\User', 'user_id');
    }

    /**
     * Получить основу заказа
     */
    public function paid_data()
    {
        return $this->hasOne('App\Models\Paid', 'attach_id');
    }




    public function cruds()
    {
        return [
            'options'   => [],
            'sorttable' => true,
            'items'     => [
                [
                    'label'    => '',
                    'id'       => 'item_check',
                    'cols'     => false,
                    'template' => 'item_check',
                    'header'   => 'item_check',
                ],
                [
                    'label'    => 'ID',
                    'id'       => 'id',
                    'cols'     => false,
                    'template' => 'text',
                    'header'   => 'order',
                ],
                [
                    'label'            => 'Сумма пополнения',
                    'id'               => 'payment_total',
                    'cols'             => false,
                    'template'         => 'text_link',
                    'href_route_name'  => 'dash.deposits.edit',
                    'href_route_value' => 'id',
                    'value_currency'   => 'formatSTRING',
                    'header'           => 'order',
                ],
                [
                    'label'    => 'ID пользователя',
                    'id'       => 'user_id',
                    'cols'             => false,
                    'template' => 'user',
                    'header'   => false,
                ],
                [
                    'label'    => 'Метод оплаты',
                    'id'       => 'payment_method',
                    'cols'     => false,
                    'template' => 'text',
                    'header'   => 'order',
                ],
                [
                    'label'    => 'ID платежа',
                    'id'       => 'paid_data',
                    'cols'     => false,
                    'template' => 'paid_data',
                    'header'   => false,
                ],
                [
                    'label'    => 'Статус',
                    'id'       => 'paid',
                    'cols'     => false,
                    'template' => 'paid',
                    'header'   => 'order',
                ],
                [
                    'label'    => 'Дата оплаты',
                    'id'       => 'payment_at',
                    'cols'     => false,
                    'template' => 'date',
                    'header'   => 'order',
                ],
                'created_at' => [
                    'label'    => 'Дата создания',
                    'id'       => 'created_at',
                    'cols'     => false,
                    'template' => 'date',
                    'header'   => 'order',
                ],
                'control'    => [
                    'label'    => '',
                    'id'       => '',
                    'cols'     => false,
                    'template' => 'control',
                    'buttons'  => [
                        [
                            'label'            => 'Изменить',
                            'href_route_name'  => 'dash.deposits.edit',
                            'href_route_value' => 'id',
                            'class'            => 'btn btn-secondary',
                            'icon'             => 'oi oi-pencil',
                            'attrs'            => []
                        ],
                        [
                            'label' => 'Удалить',
                            'href'  => '#',
                            'class' => 'btn btn-danger',
                            'icon'  => 'oi oi-x',
                            'attrs' => [
                                'data-crud-btn-remove-id' => '__ID__'
                            ]
                        ]
                    ],
                    'header'   => false,
                ],
            ]
        ];
    }



    public function getFilterLinks()
    {
        $modelTabs = DB::table('deposits')
            ->select(DB::raw('deposits.paid as paid_name, count(deposits.paid) as paid_count'))
            ->groupBy('deposits.paid')
            ->get();

        if(!$modelTabs) return false;

        $tabsItems = [];
        foreach ($modelTabs as $tabData) {
            $tabsItems[$tabData->paid_name] = $tabData->paid_count;
        }
        $tabsItems['all'] = array_sum($tabsItems);

        return $tabsItems;
    }




    /*
     * Исполняем заказ
     */
    public function _extractPaidSuccess($core)
    {
        /*
         * Загружаем данные пользователя
         */
        $user = User::find($core->paidOptions->user_id);
        if(!$user)
        {
            $core->paidData['info'] = 'Пользователь не найден';
            return $core;
        }

        $payTotal = $core->paidOptions->payment_total;

        $balancePlus = $user->changeBalance('plus', $payTotal);

    }
}
