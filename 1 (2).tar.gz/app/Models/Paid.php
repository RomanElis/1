<?php

namespace App\Models;

use App\Models\SystemPayment\SystemPayment;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class Paid extends Model
{
    use HasFactory;

    var $request;

    var $modelMain;
    var $modelType;
    var $paidId;
    var $paidSlug;
    var $paidOptions;
    var $paidData = [
        'paid'          => false,
        'info'          => '',
        'status'        => false,
        'redirect'      => false,
        'create_status' => false,
        'create_id'     => '',
        'create_slug'     => '',
        'create_type'     => '',

        'balance'   => false,
        'fund_need' => false,

        'pay' => [
            'name'     => '',
            'id'       => '',
            'email'    => '',
            'quantity' => '',
            'total'    => ''
        ]
    ];


    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'attach_id',
        'type',
    ];

    public $timestamps = false;

    /**
     * Получить данные
     */
    public function purchase_data()
    {
        return $this->belongsTo('App\Models\Purchase', 'attach_id');
    }

    public function __construct(array $attributes = [])
    {
        parent::__construct($attributes);
        $this->request = new Request;
    }


    /*
     * Ищем PAID заказ и подключаем к нему модель метода заказа
     */
    public function findPay($slug, $stausPaid = 0)
    {
        //$loadPaid = new Paid;
        if(is_numeric($slug))
        {
            $this->modelMain = $this::whereId($slug)->first();
        }
        else
        {
            $this->modelMain = $this::whereSlug($slug)->first();
        }
        if(!$this->modelMain) return $this;

        $nameMethod = 'App\Models\\' . $this->modelMain->type;
        $this->modelType = new $nameMethod();
        $this->paidOptions = $this->modelType::where('id', $this->modelMain->attach_id)->where('paid', $stausPaid)->first();
        if(!$this->paidOptions) return $this;

        $this->paidId = $this->modelMain->id;
        $this->paidSlug = $this->modelMain->slug;

        $this->paidData['create_type'] = mb_strtolower($this->modelMain->type); // No used
        $this->paidData['create_id'] = $this->modelMain->id;
        $this->paidData['create_slug'] = $this->modelMain->slug;

        $this->paidData['pay']['pay_id'] = $this->modelMain->id;
        $this->paidData['pay']['email'] = $this->paidOptions->user_email;
        $this->paidData['pay']['quantity'] = $this->paidOptions->quantity;
        $this->paidData['pay']['total'] = $this->paidOptions->payment_total;
        return $this;
    }


    /*
     * Если оплата прошла успешно, производим действие и заканчиваем заказ
     */
    public function extractPaid($callback = false)
    {
        if(!$this->modelMain) return $this;
        if(!$this->paidOptions) return $this;
        if($this->paidData['return'] == 'local')
        {
            if(!($this->paidData['paid'] && $this->paidData['paid']['status']))
            {
                return false;
            }
        }


        /*
         * Исполняем заказ
         */
        //$this->modelType =
        $this->modelType->_extractPaidSuccess($this);


        /* Записываем инфо об оплате, возможно ошибку */
        $this->paidOptions->payment_info = $this->paidData['info'] ? $this->paidData['info'] : '';


        /*
         * Завершаем заказ
         */
        if($callback)
        {
            $this->paidOptions->real_money = 1;
        }
        $this->paidOptions->paid = 1;
        $this->paidOptions->payment_at = Carbon::now();
        $hasPaidCreate = $this->paidOptions->save();


        return $this;
    }



    public function goPay()
    {
        if(!$this->modelMain) return $this;
        if(!$this->paidOptions) return $this;
        /*
         * Данные для возврата
         */
        $this->paidData['create_id'] = $this->paidId;
        $this->paidData['create_slug'] = $this->paidSlug;
        $this->paidData['pay']['email'] = $this->paidOptions->user_email;
        $this->paidData['pay']['quantity'] = $this->paidOptions->quantity;
        $this->paidData['pay']['total'] = $this->paidOptions->payment_total;

        /*
         * Проверяем и загружаем систему оплаты
         */
        $systemPaymentAvailable = (new SystemPayment)->getSystems()->whereActivity()->findById($this->paidOptions->payment_method);
        if(!$systemPaymentAvailable->hasExist())
        {
            $this->paidData['info'] = 'Платежная система не найдена или не доступна.';
            return $this;
        }
        $this->paidData['pay']['id'] = $systemPaymentAvailable->item['id'];
        $this->paidData['pay']['name'] = $systemPaymentAvailable->item['name'];



        /*
         * Метод оплаты
         */
        if($systemPaymentAvailable->item['method'] == 'callback')
        {

        }

        /*
         * Загружаем пользователя заказа
         */
        $user = User::find($this->paidOptions->user_id);

        /*
         * Загружаем системы оплаты
         */
        $systemPayment = $systemPaymentAvailable->setOption('createData', [
            'user_id'      => $this->paidOptions->user_id,
            'user'         => $user,
            'pay_id'       => $this->paidId,
            'product_id'   => $this->paidOptions->product_id,
            'quantity'     => $this->paidOptions->quantity,
            'total'        => $this->paidOptions->payment_total,
            'redirect_url' => route('payment_callback', ['system' => $this->paidOptions->payment_method, 'method' => 'success'])
        ])->loadCreator();

        $systemPaymentCreator = $systemPayment->loadCreator->createData(true);

        $this->paidData['info'] = $systemPaymentCreator->getPaymentData('info');
        $this->paidData['status'] = $systemPaymentCreator->getPaymentData('status');
        $this->paidData['return'] = $systemPaymentCreator->getPaymentData('return');
        $this->paidData['redirect'] = $systemPaymentCreator->getPaymentData('url');

        if(!$this->paidData['status'])
        {
            return $this;
        }

        /*
         * Если оплата была с баланса, возвращаем обновленный баланс и другие данные
         */
        $this->paidData['paid'] = $systemPaymentCreator->getPaymentData('user_pay');


        $this->paidData['create_status'] = true;
        $this->paidData['status'] = true;

        /*
         * Возвращаем результат
         */
        return $this;
    }



    public function createPay($ss)
    {
        $options = [
            'product_id' => 0,
            'quantity'   => 0,
            'payment'    => 0,
            'subsystem'  => 0,
            'user_id'  => 0,
            'user'  => false,
            'email'      => 0,
        ];
        $options = array_merge($options, $ss);


        /*
         * Данные для возврата
         */
        $data = [
            'paid'          => false,
            'info'          => '',
            'status'        => false,
            'redirect'      => false,
            'create_status' => false,
            'create_id'     => false,
            'create_slug' => false,

            'balance'   => false,
            'fund_need' => false,

            'pay' => [
                'title'    => '',
                'name'     => '',
                'id'       => '',
                'email'    => $options['email'],
                'quantity' => $options['quantity'],
                'total'    => ''
            ]
        ];

        /*
         * Загружаем товар
         */
        $product = Product::find($options['product_id']);
        if(!$product)
        {
            // Err
            return array_merge($data, ['info' => 'Товар не найден.']);
        }


        /*
         * Проверяем количество товара
         */
        if(!$product->hasGoodsQuantity($options['quantity']))
        {
            // Err
            return array_merge($data, ['info' => __('messages.product_denied_quantity')]);
        }

        /*
         * Подсчет итоговой стоимости заказа
         */
        $checkoutTotal = $product->price * $options['quantity'];


        /*
         * Проверяем и загружаем систему оплаты
         */
        $systemPaymentAvailable = (new SystemPayment)->getSystems()
            ->whereActivity()
            ->findById($options['payment']);

        if(!$systemPaymentAvailable->hasExist())
        {
            return array_merge($data, ['info' => 'Платежная система не найдена или не доступна.']);
        }

        $systemPaymentAvailable = $systemPaymentAvailable->setOption('createData', [
                'user_id'    => $options['user_id'],
                'user'  => $options['user'],
                'product_id' => $options['product_id'],
                'total'      => $checkoutTotal
            ])
            ->loadCreator();

        /*
         * Проверяем возможность оплаты этой системой,
         * например проверяем хватает ли средств для оплаты
         */
        //$systemPaymentAvailable->loadCreator->setPay([], $options);
        if(isset($systemPaymentAvailable->loadCreator) && method_exists($systemPaymentAvailable->loadCreator, 'existCost'))
        {
            $existCost = $systemPaymentAvailable->loadCreator->existCost();
            if(!$existCost->getPaymentData('status'))
            {
                $data['info'] = $existCost->getPaymentData('info');
                $data['status'] = $existCost->getPaymentData('status');
                $data['return'] = $existCost->getPaymentData('return');
                $data['redirect'] = $existCost->getPaymentData('url');
                $data['pay'] = false;

                return $data;
            }
        }


        /*
         * В случае необходимости можем изменить сумму
         */
        if(isset($existCost->payData['total']))
        {
            $checkoutTotal = $existCost->payData['total'];
        }


        /*
         * Создаем модель заказа
         */
        $entity = new Purchase;
        $entity->fill($this->request->all());

        $entity->goods = '';
        $entity->paid = 0;
        $entity->product_title = $product->title;
        $entity->product_id = $options['product_id'];
        $entity->price = $product->price;
        $entity->quantity = $options['quantity'];
        $entity->payment_method = $options['payment'];
        $entity->user_id = $options['user_id'];
        $entity->user_email = $options['email'];
        $entity->real_money = 0;
        $entity->payment_total = $checkoutTotal;


        /*
         * Создаем заказ
         */
        $data['create_status'] = $entity->save();


        /*
         * Добавляем параметры для pay
         */
        $data['pay']['id'] = $systemPaymentAvailable->item['id'];
        $data['pay']['name'] = $systemPaymentAvailable->item['name'];
        $data['pay']['total'] = $entity->payment_total;
        $data['pay']['title'] = $entity->product_title;


        /*
         * Создаем чек/проверку оплаты
         */
        $createdSlug = sha1($entity->product_id . $entity->price . $entity->quantity . $entity->payment_total . time());

        $paid = new Paid();
        $paid->attach_id = $entity->id;
        $paid->slug = $createdSlug;
        $paid->type = 'Purchase';
        $paidCreate = $paid->save();
        if(!$paidCreate)
        {
            return $data;
        }

        /*
         * Загружаем системы оплаты
         */
        $systemPayment = $systemPaymentAvailable->setOption('createData', [
            'pay_id'       => $paid->id,
            'total'        => $entity->payment_total,
            'redirect_url' => route('payment_callback', ['system' => $entity->payment_method, 'method' => 'success'])
        ]);

        $systemPaymentCreator = $systemPayment->loadCreator->createData();

        $data['info'] = $systemPaymentCreator->getPaymentData('info');
        $data['status'] = $systemPaymentCreator->getPaymentData('status');
        $data['return'] = $systemPaymentCreator->getPaymentData('return');
        $data['redirect'] = $systemPaymentCreator->getPaymentData('url');

        if(!$data['status'])
        {
            return $data;
        }


        //$paidCreate = $paid->save();

        if(!$data['create_status'])
        {
            // Err
            return array_merge($data, ['info' => 'Ошибка создания заказа.']);
        }


        $data['create_id'] = $paid->id;
        $data['create_slug'] = $createdSlug;
        $data['status'] = true;
        $data['info'] = 'Ожидает оплаты';

        /*
         * Возвращаем результат
         */
        return $data;
    }



    public function depositPay($ss)
    {
        $options = [
            'sum'       => 0,
            'payment'   => 0,
            'subsystem' => 0,
        ];
        $options = array_merge($options, $ss);


        /*
         * Данные для возврата
         */
        $data = [
            'paid'          => false,
            'info'          => '',
            'status'        => false,
            'redirect'      => false,
            'create_status' => false,
            'create_id'     => false,
            'create_slug' => false,

            'balance'   => false,
            'fund_need' => false,

            'pay' => [
                'name'     => '',
                'id'       => '',
                'email'    => '',
                'quantity' => '',
                'total'    => ''
            ]
        ];


        /*
         * Загружаем данные пользователя
         */
        $currentUser = Auth::user();

        if(!$currentUser)
        {
            // Err
            return array_merge($data, ['info' => 'Пользователь не найден.']);
        }


        /*
         * Создаем модель заказа
         */
        $entity = new Deposit;
        $entity->fill($this->request->all());

        $entity->paid = 0;
        $entity->payment_total = $options['sum'];
        $entity->payment_method = $options['payment'];
        $entity->user_id = isset($currentUser->id) ? $currentUser->id : 0;
        $entity->real_money = 0;

        /*
         * Проверяем и загружаем систему оплаты
         */
        $systemPaymentAvailable = (new SystemPayment)->getSystems()->whereActivity()->findById($options['payment']);
        if(!$systemPaymentAvailable->hasExist())
        {
            return array_merge($data, ['info' => 'Платежная система не найдена или не доступна.']);
        }
        $data['pay']['id'] = $systemPaymentAvailable->item['id'];
        $data['pay']['name'] = $systemPaymentAvailable->item['name'];
        $data['pay']['total'] = $entity->payment_total;
        $data['pay']['title'] = 'Пополнение баланса';


        /*
         * Создаем чек/проверку оплаты
         */
        $createdId = 0;
        $createdSlug = sha1($entity->payment_total . time());

        $paid = new Paid();
        $paid->attach_id = $createdId;
        $paid->slug = $createdSlug;
        $paid->type = 'Deposit';
        $paidCreate = $paid->save();
        if(!$paidCreate)
        {
            return $data;
        }

        /*
         * Загружаем системы оплаты
         */
        $systemPayment = $systemPaymentAvailable->setOption('createData', [
            'user_id'      => $entity->user_id,
            'pay_id'       => $paid->id,
            'product_id'   => 'balance',
            'total'        => $entity->payment_total,
            'redirect_url' => route('payment_callback', ['system' => $entity->payment_method, 'method' => 'success'])
        ])->loadCreator();

        $systemPaymentCreator = $systemPayment->loadCreator->createData();

        $data['info'] = $systemPaymentCreator->getPaymentData('info');
        $data['status'] = $systemPaymentCreator->getPaymentData('status');
        $data['return'] = $systemPaymentCreator->getPaymentData('return');
        $data['redirect'] = $systemPaymentCreator->getPaymentData('url');

        if(!$data['status'])
        {
            return $data;
        }

        $data['create_status'] = $entity->save();
        $createdId = $paid->id;

        $paid->attach_id = $entity->id;
        $paidCreate = $paid->save();

        if(!$data['create_status'])
        {
            // Err
            return array_merge($data, ['info' => 'Ошибка пополнения баланса.']);
        }


        $data['create_id'] = $createdId;
        $data['create_slug'] = $createdSlug;
        $data['status'] = true;
        $data['info'] = 'Ожидает оплаты';

        /*
         * Возвращаем результат
         */
        return $data;
    }


    /*
     * Извлекаем все заказы и прикрепления
     */
    static public function get_paids_attach()
    {
        $paids = DB::table('paids')
            ->leftJoin('purchases', function ($join) {
                $join->on('purchases.id', '=', 'paids.attach_id');
            })
            ->leftJoin('deposits', function ($join) {
                $join->on('deposits.id', '=', 'paids.attach_id');
            })
            ->select(
                'paids.id',
                DB::raw('group_concat(CASE
                WHEN purchases.id is not null
                    THEN purchases.id
                WHEN  deposits.id is not null
                    THEN deposits.id
                ELSE
                     "FALSE"
                END SEPARATOR "-") as attach_id')
            )
            ->where('attach_id', '!=', 'FALSE')
            ->groupBy('paids.id')
            ->get()->toArray();

        // THEN CONCAT("purchases", purchases.id)
        //$itemsPaids = array_column($paids, 'id');
        //$itemsAttach = array_column($paids, 'attach_id');

        return $paids;
    }





    /*
     * Удаление не оплаченных пополнений
     */
    static public function delete_paids()
    {
        $dayDelete = 2;

        /*
         * Ищем заказы и удаляем
         */
        $purchases = DB::table('purchases')
            ->where('paid', '=', '0')
            ->where('created_at', '<=', Carbon::now()->subDays($dayDelete)->toDateTimeString())
            ->get()->toArray();

        $purchasesIds = array_filter(array_column($purchases, 'id'));

        if($purchasesIds)
        {
            $count = Purchase::destroy($purchasesIds);
        }

        /*
         * Ищем пополнения и удаляем
         */
        $deposits = DB::table('deposits')
            ->where('paid', '=', '0')
            ->where('created_at', '<=', Carbon::now()->subDays($dayDelete)->toDateTimeString())
            ->get()->toArray();

        $depositsIds = array_filter(array_column($deposits, 'id'));

        if($depositsIds)
        {
            $count = Deposit::destroy($depositsIds);
        }
    }






}
