"use strict"

function notifyes($respone) {
    if ($respone.status === true) {
        $('#fn-notify').addToast({
            autoHide: true,
            showTimeLabel: false,
            displayTime: 6000,
            iconClass: $respone.notify.icon,
            title: $respone.notify.title,
            content: $respone.notify.text,
            type: $respone.notify.type
        });
    }
}

function notifyesError($respone) {
    return {
        'status': true,
        'notify': {
            icon: 'oi oi-check',
            title: 'Error',
            text: $respone.message,
            type: 'danger'
        }
    };
}

//Init
(function($) {
    "use strict";
    jQuery(function(){
        var $document = $(document);
        var $body = $('#body');
        var $screenWidth = $body.width();

        $body.removeClass("load--preload");



        // Визуальный редактор содержания
        if($('textarea.wysiwyg-editor-trumbowyg').length)
        {
            $('textarea.wysiwyg-editor-trumbowyg').trumbowyg({
                lang: 'ru',
                resetCss: true,
                btns: [
                    ['foreColor', 'backColor'],
                    ['viewHTML'],
                    ['undo', 'redo'],
                    ['formatting'],
                    ['strong', 'em', 'del'],
                    ['superscript', 'subscript'],
                    ['link'],
                    ['insertImage'],
                    ['justifyLeft', 'justifyCenter', 'justifyRight', 'justifyFull'],
                    ['unorderedList', 'orderedList'],
                    ['horizontalRule'],
                    ['removeformat'],
                    ['fullscreen'],
                    ['table'],
                    ['noembed']
                ],
                plugins: {
                    table: {},
                    colors: {
                        foreColorList: [
                            'ff0000', '00ff00', '0000ff'
                        ],
                        backColorList: [
                            '000', '333', '555'
                        ]
                    }
                }
            });
        }

        if($('textarea.wysiwyg-editor-tinymce').length)
        {
            $('textarea.wysiwyg-editor-tinymce').tinymce({
                height: 500,
                menubar: true,
                language: 'ru',
                plugins: [
                    'advlist autolink lists link image charmap print preview anchor',
                    'searchreplace visualblocks code fullscreen',
                    'insertdatetime media table paste code help wordcount'
                ],
                toolbar: 'undo redo | formatselect | bold italic backcolor | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | removeformat | help',
                relative_urls: false
            });
        }


        if($('textarea.wysiwyg-editor-ckeditor4').length)
        {
            $('textarea.wysiwyg-editor-ckeditor4').each(function(){
                CKEDITOR.replace( this );
            });
        }


        if($('textarea.wysiwyg-editor-ckeditor5').length)
        {
            $('textarea.wysiwyg-editor-ckeditor5').each(function(){
                ClassicEditor
                    .create( this, {
                        // toolbar: [ 'heading', '|', 'bold', 'italic', 'link' ]
                    } )
                    .then( editor => {
                        window.editor = editor;
                    } )
                    .catch( err => {
                        console.error( err.stack );
                    } );

            });
        }


        // CRUD :: Сортировка CRUD позиций в таблице
        var $sortTable = $('[data-sorttable="true"]');
        if($sortTable.length)
        {
            $sortTable.tableDnD({
                'dragHandle' : '.fn_dashcrud_drag',
                'onDragStop' : function () {

                    var $getPotisionts = $('[data-crud-item]').map(function(){
                        return Number($(this).attr('data-crud-item'));
                    }).get();

                    var $controller = '/dashboard/products/update-pos';
                    // AJAX response
                    $.ajax({
                        'url': $controller,
                        'type': 'PUT',
                        'dataType': 'json',
                        'data': {'items': $getPotisionts, '_token' : $tokenCsrf},
                        'success': function ($respone) {
                            notifyes($respone);
                        }
                    });

                }
            });
        }




        // CRUD :: Метод сохранения CRUD позиции
        $document.on('click', '[data-btn-submit-method]', function () {
            var $this = $(this);
            var $method = $this.attr('data-btn-submit-method');
            var $form = $this.closest('form');
            var $method_submit = $form.find('[name="method_submit"]');
            if($method_submit.length)
            {
                $method_submit.remove();
            }
            $form.append('<input type="hidden" name="method_submit" value="' + $method + '">');
        });



        // CRUD :: Checkeds in items for table
        var __inlineItemCheckeds = function(){
            var $itemsTable = $('[data-item-check="wrap"]');
            var $counter = $itemsTable.find('[data-item-check="current"]:checked').length;
            $itemsTable.find('[data-item-check="counter"]').text($counter);

            if(!$counter)
            {
                $itemsTable.find('[data-crud-remove="control"]').addClass('d-none');
            }
            else
            {
                $itemsTable.find('[data-crud-remove="control"]').removeClass('d-none');
            }
        };

        $document.on('click refresh-checked', '[data-item-check="current"]', function () {
            var $this = $(this);
            __inlineItemCheckeds();
            if ($this.is(':checked')) {
                $this.parents('tr').addClass('current');
                return;
            }
            $this.parents('tr').removeClass('current');
        });

        $('[data-item-check="all-current"]').change(function () {
            var checkboxes = $(this).parents('[data-item-check="wrap"]').find('[data-item-check="current"]');
            checkboxes.prop('checked', $(this).is(':checked')).trigger('refresh-checked');
        });


        var __crudItemDelete = function ($controller, $ids) {
            // AJAX response
            var $options = {
                //'url': location.href,
                'url': $controller + '/' + $ids.join(','),
                'type': 'DELETE',
                'dataType': 'json',
                //'data': JSON.stringify({'items': $ids, '_token' : $tokenCsrf}),
                'data': {'items': $ids, '_token' : $tokenCsrf},
                'success': function ($respone) {

                    if ($respone.status === true) {
                        notifyes($respone);

                        $.each($ids, function (itemIndx, itemId) {
                            $('[data-crud-item="' + itemId + '"]').fadeOut(500);
                        });

                        $('[data-item-check="wrap"]').find('[data-crud-remove="control"]').addClass('d-none');
                        //location.reload();
                    } else {
                    }

                }
            };
            $.ajax($options);
        };

        $document.on('click', '[data-crud-btn-remove-id]', function () {
            var $this = $(this);
            var $ids = [$this.attr('data-crud-btn-remove-id')];
            var $controller = $this.closest('[data-crud-controller]').attr('data-crud-controller');

            $.showConfirm({
                title: "Подтверждение", body: "Удалить запись?", textTrue: "Удалить", textFalse: "Отмена",
                onSubmit: function (result) { // callback on confirm
                    if (result) {
                        __crudItemDelete($controller, $ids);
                    }
                }
            })
        });


        $document.on('click', '[data-crud-btn-remove="btn"]', function () {
            var $this = $(this);
            var $controller = $this.closest('[data-crud-controller]').attr('data-crud-controller');

            var $ids = $( "[data-crud-remove-id]:checked" )
                .map(function() {
                    return $(this).data('crud-remove-id');
                })
                .get();

            if(!$ids)
            {
                return false;
            }

            $.showConfirm({
                title: "Подтверждение", body: "Удалить выбранные записи?", textTrue: "Удалить", textFalse: "Отмена",
                onSubmit: function (result) { // callback on confirm
                    if (result) {
                        __crudItemDelete($controller, $ids);
                    }
                }
            })
        });



        /*
        CRUD :: Детальный быстрый просмотр
         */
        $document.on('click', '[data-crud-btn-modal]', function () {
            var $this = $(this);
            var $modal = $this.attr('data-crud-btn-modal');
            var $findModal = $($modal);
            if($findModal.length)
            {
                $.showAlert({
                    title: "Подробно", body: $findModal.html(),
                    onSubmit: function (result) {
                    }
                })
            }
        });

        /*
        CRUD :: Загрузить файл товара
         */
        $document.on('change', '[data-crud-fastform]', function () {
            var $form = $(this);
            var $action = $form.attr('data-action');
            var $method = $form.attr('data-method');

            var fd = new FormData();
            fd.append('_token',$tokenCsrf);
            fd.append('_method','PUT');

            var fileElem = $form.find('[type="file"]');
            if(fileElem.length)
            {
                var filesName = fileElem.attr('name');
                var files = fileElem[0].files;
                fd.append(filesName,files[0]);
            }

            $.ajax({
                url: $action,
                type: $method,
                data: fd,
                'dataType' : "json",
                contentType: false,
                processData: false,
                'error' : function( $respone )
                {
                    notifyes(notifyesError($respone.responseJSON));
                    console.log($respone.responseJSON.message);
                },
                success: function($respone){
                    if($respone != 0){
                        notifyes($respone);

                        if($respone.rereplace)
                        {
                            $.each($respone.rereplace, function (findName, findInsert) {
                                $('[data-rereplace="' + findName + '-' + $respone.entity_id + '"]').html(findInsert);
                            });
                        }

                        fileElem.val("");

                    }else{
                        alert('file not uploaded');
                    }
                },
            });
        })

        // CRUD :: Сохранение сущности
        // $document.on('change', '[data-crud-entity]', function () {
        //     var $entity = $('[data-crud-entity]');
        //     $.ajax({
        //         url: location.href,
        //         type: 'POST',
        //         data: $('[data-crud-controller]').serialize(),
        //         'dataType' : "json",
        //         success: function($respone){
        //
        //         },
        //     });
        // })



        // CRUD :: Сортировка позиций по значению
        $document.on('click', '[data-crud-order]', function () {
            var $this = $(this);
            var $order = $this.attr('data-crud-order');
            var $orderBy = $this.attr('data-crud-orderby');
            var $location = window.location.href.split('?')[0];

            let params = new URLSearchParams(document.location.search.slice(1));
            params.delete('order');
            params.delete('orderby');

            if($order === 'desc')
            {
                $this.attr('data-crud-order', 'asc');
                params.append('order', 'desc');
            }
            else
            {
                $this.attr('data-crud-order', 'desc');
                params.append('order', 'asc');
            }
            params.append('orderby', $orderBy);

            location.href = $location + '?' + params;
        });


        // CRUD :: Product :: Загрузка файла
        $('.fn_file_paste_text').on('change',function(){
            var fileName = $(this).val();
            fileName = fileName.split('\\');
            fileName = fileName[fileName.length - 1];
            $(this).next('.custom-file-label').html(fileName);
        })


        // $document.on('submit', '.fn_ajax_form', function (e) {
        //     var $this = $(this);
        //     var $action = $this.attr('action');
        //     var $data = $this.serialize();
        //
        //     var $options = {
        //         'url': $action,
        //         'type': 'POST',
        //         'dataType': 'html',
        //         'data': $data,
        //         'success': function ($respone) {
        //
        //             var $alert = $($respone).find('#fn_notify_error').html();
        //
        //             $('#fn-notify').addToast({
        //                 autoHide: true,
        //                 showTimeLabel: false,
        //                 displayTime: 6000,
        //                 iconClass: 'oi oi-warning',
        //                 title: 'Ошибка',
        //                 content: $alert,
        //                 type: 'danger'
        //             });
        //
        //         }
        //     };
        //     $.ajax($options);
        //     return false;
        // });





        // var $jsSelect2Template = $('[data-js-select2-qtemplate]');
        // if($jsSelect2Template.length)
        // {
        //     var $insertTemplate = $($jsSelect2Template.data('qtemplate-insert'));
        //     var $getTemplate = $jsSelect2Template.data('js-select2-qtemplate');
        //     var $getTemplateHtml = $($getTemplate).html();
        //     $jsSelect2Template.each(function () {
        //         var $select = $(this);
        //         $select.select2({
        //             theme: 'bootstrap4',
        //             placeholder: ""
        //         }).change(function () {
        //             var $this = $(this);
        //             var $option = $this.find('option:selected');
        //             var $getData = $option.data();
        //
        //             var $templateHtml = $getTemplateHtml;
        //
        //             $.each($getData.options, function ($indx, $data) {
        //                 $templateHtml = $templateHtml.replace('__' + $indx.toUpperCase() + '__', $data);
        //             });
        //
        //             $insertTemplate.append($templateHtml);
        //             setTimeout(function () {
        //                 $jsSelect2Template.val(0).trigger('change');
        //             },50);
        //         });
        //     });
        // }
        //
        // $document.on('click', '[data-qtemplate="btn_remove"]', function () {
        //     var $this = $(this);
        //     var $wrap = $this.parents('[data-qtemplate="item"]');
        //     $wrap.fadeOut(300, function () {
        //         $wrap.remove();
        //     });
        //     return false;
        // });


        // MODULE :: Purchase :: Balance
        // $document.on('submit', '[data-pursase-form="wrap"]', function () {
        //     var $form = $(this);
        //     if($form.find('[name="method_submit"]').val() === 'plus') return true;
        //
        //     var $isError = [];
        //     $form.find('[data-stock]').removeClass('is-invalid').each(function () {
        //         var $this = $(this);
        //         var $value = $this.val();
        //         if($value === '') return;
        //         var $stock = Number($this.data('stock'));
        //         var $val = Number($value);
        //
        //         if($stock < $val)
        //         {
        //             $this.addClass('is-invalid');
        //             $isError.push($this);
        //         }
        //     });
        //
        //     if($isError.length)
        //     {
        //         $.showAlert({title: "Ошибка", body: "Нельзя задать отрицательный баланс"});
        //         return false;
        //     }
        // });



        /* DASH :: Chart */
        if (typeof window.chart !== 'undefined') {
            console.log(window.chart);
            var ctx = document.getElementById('myChart');
            var myChart = new Chart(ctx, {
                type: 'line',
                data: {
                    labels: window.chart.labels,
                    datasets: [{
                        "label":"Итого сумма",
                        showLine: true,
                        data: window.chart.total_cost,
                        lineTension: 0,
                        backgroundColor: 'transparent',
                        borderColor: '#007bff',
                        borderWidth: 2,
                        pointBackgroundColor: '#007bff'
                    },{
                        "label":"Итого кол.заказов",
                        showLine: true,
                        data: window.chart.total_items,
                        lineTension: 0,
                        backgroundColor: 'transparent',
                        borderColor: '#7fff54',
                        borderWidth: 2,
                        pointBackgroundColor: '#7fff54'
                    }]
                },
                options: {
                    scales: {
                        yAxes: [{
                            ticks: {
                                beginAtZero: false
                            }
                        }]
                    },
                    legend: {
                        display: true
                    }
                }
            })
        }


        /* Calendar */
        $document.on('focus', '[data-datepicker="date"]', function () {
            var $this = $(this);
            if($this.hasClass('init-script')) return;
            $this.addClass('init-script');

            var $options = {
                navTitles: {
                    days: 'MM yyyy'
                },
                maxDate: new Date(),
                moveToOtherYearsOnSelect: false,
                dateFormat: '',
                toggleSelected: false,
                showOtherYears: false,
                selectOtherYears: false,
                autoClose: false
            };
            var $datepicker = $this.datepicker($options).data('datepicker');
        });


        $document.on('change', '#customSwitch_goods_file_empty', function () {
            var $this = $(this);
            if($this.is(':checked'))
            {
                $('#goods_file_wrap').hide();
            }
            else
            {
                $('#goods_file_wrap').show();
            }
        });




        //END
    });
})(jQuery);
/* END */
