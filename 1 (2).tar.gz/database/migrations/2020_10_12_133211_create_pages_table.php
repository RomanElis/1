<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreatePagesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('pages', function (Blueprint $table) {
            $table->increments('id');
            $table->string('slug')->default('');
            $table->string('title')->default('');
            $table->string('title_h1')->default('')->nullable();
            $table->string('meta_title')->default('')->nullable();
            $table->string('meta_description')->default('')->nullable();
            $table->string('meta_keywords')->default('')->nullable();
            $table->longText('description')->default('')->nullable();
            $table->integer('parent_id')->default(0)->nullable();
            $table->integer('position')->default(0)->nullable();
            $table->tinyInteger('activity')->default(0)->nullable();
            $table->string('template_name')->default('')->nullable();
            $table->integer('lang_id')->default(0)->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('pages');
    }
}
