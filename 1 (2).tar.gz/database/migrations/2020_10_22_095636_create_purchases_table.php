<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreatePurchasesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('purchases', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('product_id')->default(0)->nullable();
            $table->string('product_title')->default('')->nullable();
            $table->integer('user_id')->default(0)->nullable();
            $table->string('user_email')->default('')->nullable();
            $table->decimal('price', 10, 2)->default(0)->nullable();
            $table->string('quantity')->default('')->nullable();
            $table->decimal('payment_total', 10, 2)->default(0)->nullable();
            $table->string('payment_method')->default('')->nullable();
            $table->string('payment_info')->default('')->nullable();
            //$table->string('url')->default('')->nullable();
            $table->integer('real_money')->default(0)->nullable();
            $table->tinyInteger('paid')->nullable();
            $table->longText('goods')->default('')->nullable();
            $table->longText('comment')->default('')->nullable();
            $table->timestamp('payment_at')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('purchases');
    }
}
