<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateDepositsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('deposits', function (Blueprint $table) {
            //$table->id();
            $table->increments('id');
            $table->integer('user_id')->default(0)->nullable();
            $table->decimal('payment_total', 10, 2)->default(0)->nullable();
            $table->string('payment_method')->default('')->nullable();
            $table->string('payment_info')->default('')->nullable();
            //$table->string('url')->default('')->nullable();
            $table->integer('real_money')->default(0)->nullable();
            $table->tinyInteger('paid')->nullable();
            $table->longText('comment')->default('')->nullable();
            $table->timestamp('payment_at')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('deposits');
    }
}
