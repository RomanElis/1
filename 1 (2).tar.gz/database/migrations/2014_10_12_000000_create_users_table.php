<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateUsersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('users', function (Blueprint $table) {
            $table->increments('id');
            $table->string('name');
            $table->string('email')->unique();
            $table->timestamp('email_verified_at')->nullable();
            $table->string('password');
            $table->string('group')->default('user');
            $table->decimal('balance', 10, 2)->default(0)->nullable(); // Баланс пользователя
            $table->text('favorites')->default('')->nullable();
            $table->timestamp('last_login')->nullable(); // Последняя авторизация
            $table->timestamp('last_payment')->nullable(); // Последнее пополнение
            $table->timestamp('last_purchase')->nullable(); // Последняя покупка
            $table->string('telegram')->default('')->nullable(); // Номер телеграма
            $table->rememberToken();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('users');
    }
}
