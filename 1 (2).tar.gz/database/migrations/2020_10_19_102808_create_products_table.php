<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateProductsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('products', function (Blueprint $table) {
            $table->increments('id');
            $table->string('title')->default('');
            $table->string('type')->default('');
            $table->string('image')->default('')->nullable();
            $table->longText('description')->default('')->nullable();
            $table->decimal('price', 10, 2)->default(0)->nullable();
            $table->longText('goods')->default('')->nullable();
            $table->integer('stock')->default(0)->nullable();
            $table->integer('position')->default(0)->nullable();
            $table->tinyInteger('activity')->default(0)->nullable();
            $table->integer('sales')->default(0)->nullable();
            $table->timestamp('last_sale')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('products');
    }
}
