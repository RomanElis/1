<?php
 return array (
  'slogan' => 'SHOP-NAME',
  'description_top' => '<p style="text-align: right;">Здесь любой текст</p>
<p style="text-align: center;"><a href="#"><img src="/uploads/main/header.png" alt="" width="460" height="80" /></a></p>
<p>Здесь любой текст</p>',
  'description_bottom' => '<p>Здесь любой текст</p>
<p style="text-align: center;"><a href="#"><img src="/uploads/main/footer.png" alt="" width="460" height="80" /></a></p>
<p style="text-align: right;">Здесь любой текст</p>
<p>&nbsp;</p>
<p>Или список пунктов</p>
<ul>
<li>Пункт 1</li>
<li>Пункт 2</li>
<li>Пункт 3</li>
</ul>
<table style="border-collapse: collapse; width: 100%;" border="1">
<tbody>
<tr>
<td>Ячейка</td>
<td>Ячейка</td>
<td>Ячейка</td>
</tr>
<tr>
<td>Ячейка</td>
<td>Ячейка</td>
<td>Ячейка</td>
</tr>
</tbody>
</table>',
  'code_head' => NULL,
  'code_foot' => NULL,
  'footer_copyright' => '<p>@ Все права защищены</p>
<a href="#"><img alt="" src="/assets/design/img/blank/stat.png"></a>',
  'footer_logo' => 'Text text',
);