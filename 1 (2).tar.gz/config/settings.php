<?php
 return array (
  'site_status' => 'online',
  'meta' => 
  array (
    'title' => '«akk-seller.online» — Онлайнмаркет аккаунтов vk, odnoklassniki, twitter, instagram и другие',
    'keywords' => 'Аккаунты, vk, odnoklassniki, twitter, instagram',
    'description' => '«akk-seller.online» — Онлайнмаркет по продаже аккаунтов vk, odnoklassniki, twitter, instagram и других аккаунтов',
  ),
  'wysiwyg_editor' => 'tinymce',
  'addcash_min' => '50',
  'recaptcha_v2' => 
  array (
    'recaptcha_private' => '6LeHWN8ZAAAAANpWfd6_qqWFJYN-QRuoBOrYTGG_',
    'recaptcha_site' => '6LeHWN8ZAAAAAAYH2eEKLf0egbuC7UqAEs0IhNGd',
  ),
  'captcha' => 
  array (
    'type' => 'recaptcha_v2',
    'recaptcha_v2_private' => '6LeHWN8ZAAAAANpWfd6_qqWFJYN-QRuoBOrYTGG_',
    'recaptcha_v2_site' => '6LeHWN8ZAAAAAAYH2eEKLf0egbuC7UqAEs0IhNGd',
  ),
  'feedback_email' => 'akk-seller-online-shop@yandex.ru',
  'feedback_name' => 'Shop-online1',
  'feedback_shop' => 'Shop-online2',
  'support_email' => 'temnik@mail.ru',
  'dashboard_key' => '123456',
);