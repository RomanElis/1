<?php
 return array (
  'freekassa' => 
  array (
    'activity' => 'enable',
    'merchant_id' => '58214',
    'pass1' => 'v1clofsh',
    'pass2' => 'd5a71ndm',
  ),
  'enotpay' => 
  array (
    'merchant_id' => NULL,
    'pass1' => NULL,
    'pass2' => NULL,
  ),
  'balance' => 
  array (
    'activity' => 'enable',
    'maxpay' => '200',
  ),
);